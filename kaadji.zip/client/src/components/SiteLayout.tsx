import { useState, type ReactNode } from "react";
import { ArrowUpRight, HeartHandshake, Menu, ShieldCheck, X } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useLanguage } from "@/contexts/LanguageContext";

export default function SiteLayout({ children }: { children: ReactNode }) {
  const { t, toggleLanguage } = useLanguage();
  const [location] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);

  const navItems = [
    { href: "/", label: t("home") },
    { href: "/find-care", label: t("findCare") },
    { href: "/become-caregiver", label: t("becomeCaregiver") },
    { href: "/how-it-works", label: t("howItWorks") },
    { href: "/help", label: t("help") },
  ];

  return (
    <div className="site-shell">
      <a className="skip-link" href="#main-content">Skip to main content</a>
      <header className="site-header">
        <div className="site-header-inner">
          <Link href="/" className="brand-logo" aria-label="Kaadji home">
            <img src="/manus-storage/KaadjiWellnessLogo_23876928.png" alt="Kaadji — Prevent, Care, Heal" />
          </Link>
          <nav className="desktop-nav" aria-label="Main navigation">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href} className={location === item.href ? "nav-link active" : "nav-link"}>
                {item.label}
              </Link>
            ))}
          </nav>
          <div className="header-actions">
            <button className="language-button" type="button" onClick={toggleLanguage} aria-label="Change language">
              {t("language")}
            </button>
            <Link href="/login" className="login-link">{t("login")} <ArrowUpRight size={15} /></Link>
          </div>
          <button className="mobile-menu-button" type="button" aria-label={menuOpen ? "Close menu" : "Open menu"} aria-expanded={menuOpen} onClick={() => setMenuOpen((open) => !open)}>
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
        {menuOpen && (
          <nav className="mobile-nav" aria-label="Mobile navigation">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href} onClick={() => setMenuOpen(false)}>{item.label}</Link>
            ))}
            <Link href="/login" onClick={() => setMenuOpen(false)}>{t("login")}</Link>
            <button type="button" onClick={toggleLanguage}>{t("language")}</button>
          </nav>
        )}
      </header>

      <main id="main-content">{children}</main>

      <aside className="support-strip" aria-label="Prototype support notice">
        <div className="support-icon"><HeartHandshake size={20} /></div>
        <div className="support-copy">
          <strong>{t("support")}</strong>
          <span>{t("supportNotLive")}</span>
        </div>
        <Link href="/help" className="support-action">Get help <ArrowUpRight size={15} /></Link>
      </aside>

      <footer className="site-footer">
        <div className="footer-main">
          <div className="footer-brand">
            <Link href="/" className="brand-logo" aria-label="Kaadji home">
              <img src="/manus-storage/KaadjiWellnessLogo_23876928.png" alt="Kaadji — Prevent, Care, Heal" />
            </Link>
            <p>Care that respects the person, the family, and the work of caregivers.</p>
          </div>
          <div className="footer-links">
            <span className="footer-heading">Explore</span>
            <Link href="/find-care">Find care</Link>
            <Link href="/become-caregiver">Become a caregiver</Link>
            <Link href="/how-it-works">How it works</Link>
          </div>
          <div className="footer-links">
            <span className="footer-heading">Need support?</span>
            <Link href="/help">Help & replacement</Link>
            <Link href="/operator">Operator demo</Link>
            <span className="emergency-note"><ShieldCheck size={14} /> Immediate danger in India: call 112.</span>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© 2026 Kaadji · Prototype concept</span>
          <span className="prototype-disclaimer">No live caregiver availability, bookings, payments, or support in this prototype.</span>
        </div>
      </footer>
    </div>
  );
}
