type PortraitPlaceholderProps = {
  variant?: "a" | "b" | "c" | "d" | "e";
  className?: string;
  label?: string;
  photoPath?: string;
};

export default function PortraitPlaceholder({
  variant = "a",
  className = "",
  label = "Illustrative profile portrait placeholder",
  photoPath,
}: PortraitPlaceholderProps) {
  return (
    <div className={`portrait-art portrait-art-${variant} ${className}`} role="img" aria-label={label}>
      {photoPath ? (
        <>
          <span className="portrait-photo-fallback" aria-hidden="true">Sample portrait</span>
          <img
            className="portrait-photo"
            src={photoPath}
            alt=""
            aria-hidden="true"
            loading="lazy"
            onError={(event) => {
              event.currentTarget.style.display = "none";
            }}
          />
          <span className="portrait-caption" aria-hidden="true">Fictional AI-generated sample</span>
        </>
      ) : (
        <>
          <span className="portrait-sun" aria-hidden="true" />
          <span className="portrait-leaf portrait-leaf-one" aria-hidden="true" />
          <span className="portrait-leaf portrait-leaf-two" aria-hidden="true" />
          <span className="portrait-head" aria-hidden="true" />
          <span className="portrait-body" aria-hidden="true" />
          <span className="portrait-caption" aria-hidden="true">Portrait placeholder</span>
        </>
      )}
    </div>
  );
}
