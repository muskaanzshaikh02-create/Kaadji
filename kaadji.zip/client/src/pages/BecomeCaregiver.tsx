import { useState } from "react";
import { ArrowLeft, ArrowRight, Check, FileText, HeartHandshake, ShieldCheck, Sparkles } from "lucide-react";

const applicationStatuses = ["Application Submitted", "Verification Pending", "Additional Information Required", "Approved", "Rejected", "Temporarily Suspended"];

export default function BecomeCaregiver() {
  const [step, setStep] = useState(1);
  const [submitted, setSubmitted] = useState(false);
  const [homeCare, setHomeCare] = useState(true);
  const [hospitalCare, setHospitalCare] = useState(false);

  return <div className="page-wrap inner-page">
    <div className="page-intro">
      <span className="section-kicker">Caregiver journey · prototype</span>
      <h1>Your experience deserves a clear place to begin.</h1>
      <p>A short application concept for people interested in offering non-clinical caregiving support.</p>
    </div>
    <div className="demo-warning"><Sparkles size={16} /><span>Demonstration only. This page does not send, save or verify your information. Please do not enter real personal details or upload actual documents.</span></div>
    <div className="application-layout">
      <section className="application-card">
        {submitted ? <div className="application-success"><span className="success-icon"><Check size={22} /></span><span className="section-kicker">Sample status</span><h2>Application Submitted</h2><p>Your demonstration journey ends here. A real application would move to verification only after a secure submission and informed consent.</p><button className="button button-outline" onClick={() => { setSubmitted(false); setStep(1); }}>Review the steps again</button></div> : <>
          <div className="application-progress"><div className="progress-track"><span style={{ width: `${(step / 3) * 100}%` }} /></div><div className="progress-labels"><span>01 · About you</span><span>02 · Your work</span><span>03 · Review</span></div></div>
          <div className="flow-heading"><div className="flow-step-number">0{step}</div><div><span className="section-kicker">Step {step} of 3</span><h2>{step === 1 ? "A little about you" : step === 2 ? "The support you offer" : "Review the sample application"}</h2></div></div>
          {step === 1 && <div className="form-stack">
            <label className="field-block"><span>Full legal name</span><input placeholder="Not collected in this prototype" disabled /></label>
            <div className="form-grid-two"><label className="field-block"><span>Mobile number</span><input type="tel" inputMode="tel" placeholder="Not collected in this prototype" disabled /></label><label className="field-block"><span>Email (optional)</span><input type="email" placeholder="Not collected in this prototype" disabled /></label></div>
            <label className="field-block"><span>Home address (later secure step)</span><input placeholder="Not collected in this prototype" disabled /></label>
            <div className="upload-placeholder"><FileText size={21} /><div><strong>Profile photo placeholder</strong><span>Photo selection is not enabled in this prototype.</span></div><button type="button" disabled>Unavailable</button></div>
            <label className="field-block"><span>Preferred language(s)</span><select defaultValue=""><option value="" disabled>Select language</option><option>Marathi</option><option>Hindi</option><option>English</option><option>Multiple languages</option></select></label>
            <div className="privacy-callout"><ShieldCheck size={18} /><p>Identity and care information should be requested only when needed, with a clear explanation of who can access it.</p></div>
          </div>}
          {step === 2 && <div className="form-stack">
            <label className="field-block"><span>Preferred service locations</span><input placeholder="City, neighbourhood or PIN code" /></label>
            <div className="form-grid-two"><label className="field-block"><span>Relevant experience</span><select defaultValue=""><option value="" disabled>Select range</option><option>Less than 1 year</option><option>1–3 years</option><option>3–5 years</option><option>5+ years</option></select></label><label className="field-block"><span>Skills / support experience</span><select defaultValue=""><option value="" disabled>Select an area</option><option>Companionship</option><option>Mobility assistance</option><option>Daily-living support</option><option>Supervision</option></select></label></div>
            <label className="field-block"><span>Relevant training or qualification (where applicable)</span><input placeholder="Not collected or verified in this prototype" disabled /></label>
            <div className="field-block"><span>Care settings (choose all that apply)</span><div className="checkbox-row"><label className="checkbox-card"><input type="checkbox" checked={homeCare} onChange={(event) => setHomeCare(event.target.checked)} /> <span>Home care</span></label><label className="checkbox-card"><input type="checkbox" checked={hospitalCare} onChange={(event) => setHospitalCare(event.target.checked)} /> <span>Hospital care, subject to policy</span></label></div></div>
            <label className="field-block"><span>Availability (example)</span><select defaultValue=""><option value="" disabled>Select a preference</option><option>Weekdays</option><option>Weekends</option><option>Flexible shifts</option></select></label>
            <label className="field-block"><span>Emergency contact (requested at a later secure stage)</span><input placeholder="Not collected in this prototype" disabled /></label>
          </div>}
          {step === 3 && <div className="form-stack">
            <div className="review-summary"><div><span>Identity verification</span><strong>Separate check · pending in real service</strong></div><div><span>Professional qualifications</span><strong>Reviewed separately; no qualification is assumed</strong></div><div><span>Application decision</span><strong>Application Submitted → Verification Pending</strong></div></div>
            <div className="upload-placeholder"><FileText size={22} /><div><strong>Document upload placeholder</strong><span>Secure upload would be added after approval. Do not attach real documents here.</span></div><button type="button" disabled>Upload unavailable</button></div>
            <div className="privacy-callout"><ShieldCheck size={18} /><p>Nothing on this page is saved. A production flow would explain each document's purpose, access and retention before collection.</p></div>
          </div>}
          <div className="application-actions">{step > 1 ? <button type="button" className="button button-text" onClick={() => setStep(step - 1)}><ArrowLeft size={16} /> Back</button> : <span />}{step < 3 ? <button type="button" className="button button-primary" onClick={() => setStep(step + 1)}>Continue <ArrowRight size={16} /></button> : <button type="button" className="button button-primary" onClick={() => setSubmitted(true)}>Show sample submission <Check size={16} /></button>}</div>
        </>}
      </section>
      <aside className="application-aside">
        <div className="aside-icon"><HeartHandshake size={23} /></div><span className="section-kicker">A fair, clear process</span><h3>Verification is a responsibility.</h3><p>Identity checks and professional qualification checks are separate. A caregiver is not described as a nurse or clinically qualified without the right credentials.</p>
        <div className="status-list-heading">Possible application statuses</div><div className="status-list">{applicationStatuses.map((status, index) => <div className="status-list-item" key={status}><span className={index === 0 ? "status-number current" : "status-number"}>{index + 1}</span><span>{status}</span></div>)}</div>
        <p className="tiny-disclaimer">All statuses shown are examples only. This prototype does not make a verification decision.</p>
      </aside>
    </div>
  </div>;
}
