import { useMemo, useState } from "react";
import { ArrowRight, BadgeCheck, CalendarDays, Check, ChevronDown, Clock3, Heart, MapPin, ShieldCheck, SlidersHorizontal, Sparkles, X } from "lucide-react";
import { Link } from "wouter";
import { useLanguage } from "@/contexts/LanguageContext";
import PortraitPlaceholder from "@/components/PortraitPlaceholder";
import { demoCaregivers, demoPrivacyNotice, type DemoProfile } from "@shared/demo-data";

export default function FindCare() {
  const { t: translate } = useLanguage();
  const query = new URLSearchParams(window.location.search);
  const [setting, setSetting] = useState(query.get("setting") === "hospital" ? "Hospital care" : query.get("setting") === "home" ? "Home care" : "Any care type");
  const [city, setCity] = useState(query.get("location") ?? "");
  const [pin, setPin] = useState("");
  const [careNeed, setCareNeed] = useState("");
  const [preferredDate, setPreferredDate] = useState("");
  const [startTime, setStartTime] = useState("");
  const [duration, setDuration] = useState("");
  const [skill, setSkill] = useState("Any skill");
  const [language, setLanguage] = useState("Any language");
  const [minimumExperience, setMinimumExperience] = useState("0");
  const [maxPrice, setMaxPrice] = useState("400");
  const [ratingState, setRatingState] = useState("Any review status");
  const [availability, setAvailability] = useState("Any availability");
  const [showFilters, setShowFilters] = useState(false);
  const [selected, setSelected] = useState<DemoProfile | null>(null);
  const [bookingDone, setBookingDone] = useState(false);
  const [favorites, setFavorites] = useState<string[]>([]);

  const filteredProfiles = useMemo(() => demoCaregivers.filter((profile) => {
    const normalizedCity = city.trim().toLowerCase();
    const matchesCity = !normalizedCity || profile.city.toLowerCase().includes(normalizedCity) || profile.area.toLowerCase().includes(normalizedCity);
    const matchesPin = !pin.trim() || profile.pinCode.startsWith(pin.trim());
    const matchesSetting = setting === "Any care type" || profile.settings.includes(setting);
    const matchesSkill = skill === "Any skill" || profile.skills.includes(skill);
    const matchesLanguage = language === "Any language" || profile.languages.includes(language);
    const matchesExperience = profile.years >= Number(minimumExperience || 0);
    const matchesPrice = profile.priceInr <= Number(maxPrice || 0);
    const hasEligibleReviews = profile.eligibleReviewCount > 0;
    const matchesRating = ratingState === "Any review status" || (ratingState === "No eligible reviews yet" && !hasEligibleReviews) || (ratingState === "Has eligible reviews" && hasEligibleReviews);
    const matchesAvailability = availability === "Any availability" || (availability === "Illustrative dates only" && profile.availability.startsWith("Illustrative"));
    return matchesCity && matchesPin && matchesSetting && matchesSkill && matchesLanguage && matchesExperience && matchesPrice && matchesRating && matchesAvailability;
  }), [availability, city, language, maxPrice, minimumExperience, pin, ratingState, setting, skill]);

  const clearFilters = () => {
    setCity("");
    setPin("");
    setCareNeed("");
    setPreferredDate("");
    setStartTime("");
    setDuration("");
    setSkill("Any skill");
    setLanguage("Any language");
    setMinimumExperience("0");
    setMaxPrice("400");
    setRatingState("Any review status");
    setAvailability("Any availability");
    setSetting("Any care type");
  };

  return (
    <div className="page-wrap inner-page">
      <div className="page-intro">
        <span className="section-kicker">Find care · prototype</span>
        <h1>Start with what matters most.</h1>
        <p>Choose a setting, tell us where and when, then explore the information a family should be able to compare.</p>
      </div>
      <div className="demo-warning"><Sparkles size={16} /><span>{translate("sample")} — all five portraits and profiles below are fictional examples. Search and filters run locally; no real caregiver, booking, verification, availability or patient record is connected.</span></div>

      <section className="search-flow-card" aria-label="Care request details">
        <div className="flow-heading"><div className="flow-step-number">01</div><div><span className="section-kicker">Your care request</span><h2>Tell us a little about the support</h2></div></div>
        <div className="search-form-grid">
          <label className="field-block"><span>{translate("careChoice")}</span><select value={setting} onChange={(event) => setSetting(event.target.value)}><option>Any care type</option><option>Home care</option><option>Hospital care</option></select></label>
          <label className="field-block"><span>City or neighbourhood</span><div className="input-with-icon"><MapPin size={17} /><input value={city} onChange={(event) => setCity(event.target.value)} placeholder="Pune, Mumbai, Nashik…" /></div></label>
          <label className="field-block"><span>PIN code (search only)</span><input inputMode="numeric" maxLength={6} value={pin} onChange={(event) => setPin(event.target.value.replace(/\D/g, ""))} placeholder="6-digit PIN code" /></label>
          <label className="field-block"><span>Preferred date</span><div className="input-with-icon"><CalendarDays size={17} /><input type="date" aria-label="Illustrative preferred date" value={preferredDate} onChange={(event) => setPreferredDate(event.target.value)} /></div></label>
          <label className="field-block"><span>Start time</span><div className="input-with-icon"><Clock3 size={17} /><input type="time" aria-label="Illustrative start time" value={startTime} onChange={(event) => setStartTime(event.target.value)} /></div></label>
          <label className="field-block"><span>Type of assistance</span><select value={careNeed} onChange={(event) => setCareNeed(event.target.value)}><option value="">Choose a support need</option><option>Companionship</option><option>Daily living</option><option>Mobility support</option><option>Supervision</option><option>Post-discharge non-clinical support</option></select></label>
          <label className="field-block"><span>Expected duration</span><select value={duration} onChange={(event) => setDuration(event.target.value)}><option value="">Choose a duration</option><option>Short visit · example</option><option>Daytime support · example</option><option>Proposed 24-hour arrangement · not defined</option><option>Longer arrangement · operator discussion</option></select></label>
        </div>
        <div className="search-form-bottom"><p><ShieldCheck size={16} /> This local demo shows only a general area and non-clinical care summary to a matched caregiver.</p><button className="button button-primary" type="button" onClick={() => document.getElementById("caregiver-results")?.scrollIntoView({ behavior: "smooth", block: "start" })}>Explore illustrative profiles <ArrowRight size={17} /></button></div>
      </section>

      <section id="caregiver-results" className="results-section">
        <div className="results-title-row"><div><span className="section-kicker">Compare with clarity</span><h2>Caregiver examples</h2><p className="results-count">{filteredProfiles.length} of {demoCaregivers.length} fictional sample profiles · not a live search</p></div><button className="filter-toggle" type="button" onClick={() => setShowFilters((open) => !open)} aria-expanded={showFilters}><SlidersHorizontal size={17} /> Filters <ChevronDown size={15} /></button></div>
        {showFilters && <div className="filter-panel">
          <label className="field-block"><span>Skill</span><select value={skill} onChange={(event) => setSkill(event.target.value)}><option>Any skill</option><option>Companionship</option><option>Daily living</option><option>Mobility support</option><option>Supervision</option></select></label>
          <label className="field-block"><span>Language</span><select value={language} onChange={(event) => setLanguage(event.target.value)}><option>Any language</option><option>Marathi</option><option>Hindi</option><option>English</option></select></label>
          <label className="field-block"><span>Experience (years, minimum)</span><select value={minimumExperience} onChange={(event) => setMinimumExperience(event.target.value)}><option value="0">Any experience</option><option value="3">3+ years</option><option value="5">5+ years</option><option value="8">8+ years</option></select></label>
          <label className="field-block"><span>Maximum illustrative price</span><select value={maxPrice} onChange={(event) => setMaxPrice(event.target.value)}><option value="400">₹400 proposed arrangement</option><option value="0">Under ₹400</option></select></label>
          <label className="field-block"><span>Rating / review status</span><select value={ratingState} onChange={(event) => setRatingState(event.target.value)}><option>Any review status</option><option>No eligible reviews yet</option><option>Has eligible reviews</option></select></label>
          <label className="field-block"><span>Availability</span><select value={availability} onChange={(event) => setAvailability(event.target.value)}><option>Any availability</option><option>Illustrative dates only</option></select></label>
        </div>}
        {filteredProfiles.length > 0 ? <div className="search-result-list">{filteredProfiles.map((profile) => <article className="care-result-card" key={profile.id}>
          <div className="result-photo"><PortraitPlaceholder variant={profile.id} photoPath={profile.photoPath} label={`Fictional AI-generated sample portrait for ${profile.name}; not a real caregiver`} /><span className="profile-demo-chip">Fictional sample</span></div>
          <div className="result-main"><div className="profile-name-row"><h3>{profile.name}</h3><BadgeCheck size={17} className="badge-muted" aria-label="Verification is not live" /></div><p className="profile-role"><MapPin size={14} /> {profile.area}, {profile.city} · sample service area</p><p className="result-intro">{profile.intro}</p><div className="tag-row">{profile.skills.map((item) => <span className="soft-tag" key={item}>{item}</span>)}{profile.languages.map((item) => <span className="soft-tag" key={item}>{item}</span>)}</div><div className="profile-facts"><span>{profile.years} years' experience · illustrative</span><span>{profile.settings.join(" · ")}</span></div><div className="verification-line"><span className="status-dot status-demo" /> Verification is not live <span className="dot-separator">·</span>{profile.availability}</div></div>
          <div className="result-side"><div className="result-price">₹{profile.priceInr} <small>proposed / 24 hours*</small></div><span className="no-reviews">No eligible reviews</span><button type="button" className="favorite-toggle" aria-pressed={favorites.includes(profile.id)} onClick={() => setFavorites((current) => current.includes(profile.id) ? current.filter((id) => id !== profile.id) : [...current, profile.id])}><Heart size={15} fill={favorites.includes(profile.id) ? "currentColor" : "none"} /> {favorites.includes(profile.id) ? "Saved sample" : "Save sample"}</button><button type="button" className="button button-outline compact-button" onClick={() => { setSelected(profile); setBookingDone(false); }}>View matched details <ArrowRight size={16} /></button></div>
        </article>)}</div> : <div className="empty-results"><div className="empty-icon"><Heart size={20} /></div><h3>No illustrative match for those filters</h3><p>In a live service, families could request operator assistance when no suitable caregiver is available.</p><div className="empty-actions"><Link href="/help" className="button button-primary">Ask for operator assistance <ArrowRight size={16} /></Link><button type="button" className="button button-outline" onClick={clearFilters}>Clear filters</button></div></div>}
        <p className="price-footnote">* ₹400 is a proposed rate for a 24-hour arrangement, not a final quote. The arrangement, rest and working conditions must be defined before launch.</p>
      </section>

      <div className="clinical-note clinical-note-card"><ShieldCheck size={18} /><span>Non-clinical caregiving only. Regulated clinical nursing must be provided only by appropriately qualified and authorised professionals where legally permitted.</span></div>

      {selected && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setSelected(null); }}><section className="prototype-modal match-modal" role="dialog" aria-modal="true" aria-labelledby="profile-modal-title"><button type="button" className="modal-close" aria-label="Close" onClick={() => setSelected(null)}><X size={20} /></button>{bookingDone ? <div className="modal-success"><span className="success-icon"><Check size={22} /></span><span className="section-kicker">Demo state only</span><h2 id="profile-modal-title">Your sample request is ready.</h2><p>No booking has been sent. In a live product, a caregiver would need to accept before the booking is confirmed.</p><p className="modal-fine-print">Patient identity, contact details and exact address remain hidden. This prototype has no real patient or booking data.</p><button type="button" className="button button-primary" onClick={() => setSelected(null)}>Done</button></div> : <>
        <div className="modal-profile-head"><PortraitPlaceholder variant={selected.id} photoPath={selected.photoPath} className="modal-avatar-placeholder" label={`Fictional AI-generated sample portrait for ${selected.name}; not a real caregiver`} /><div><span className="prototype-badge"><Sparkles size={13} /> Fictional sample</span><h2 id="profile-modal-title">{selected.name}</h2><p>{selected.area}, {selected.city} · illustrative service area</p></div></div>
        <section className="match-summary" aria-labelledby="patient-summary-title"><span className="section-kicker">Matched request · sample only</span><h3 id="patient-summary-title">Patient care summary</h3><div className="match-summary-grid"><div><span>Care setting</span><strong>{setting === "Any care type" ? "Not specified · any setting" : setting}</strong></div><div><span>Support requested</span><strong>{careNeed || "Not selected"}</strong></div><div><span>General area</span><strong>{city.trim() || "Not specified"} · exact PIN/address hidden</strong></div><div><span>Preferred schedule</span><strong>{[preferredDate || "Date not set", startTime || "time not set", duration || "duration not selected"].join(" · ")}</strong></div></div><p>{demoPrivacyNotice}</p></section>
        <div className="modal-details"><span className="section-kicker">Caregiver details · illustrative only</span><div className="modal-detail-row"><span>Verification</span><strong>Not verified — example only</strong></div><div className="modal-detail-row"><span>Experience</span><strong>{selected.years} years (illustrative)</strong></div><div className="modal-detail-row"><span>Skills and languages</span><strong>{selected.skills.join(", ")} · {selected.languages.join(", ")}</strong></div><div className="modal-detail-row"><span>Training / qualifications</span><strong>{selected.training}</strong></div><div className="modal-detail-row"><span>Home / hospital eligibility</span><strong>{selected.settings.join(" · ")}</strong></div><div className="modal-detail-row"><span>Completed bookings / eligible reviews</span><strong>None in this prototype</strong></div><div className="modal-detail-row"><span>Availability</span><strong>{selected.availability}</strong></div><div className="modal-price-box"><span>Proposed service charge</span><strong>₹{selected.priceInr} <small>per defined 24-hour arrangement</small></strong><p>Provisional only. Attendance, rest, duties, handovers, meals, transport, extensions and staffing terms must be defined before launch.</p></div><div className="modal-detail-row"><span>Patient/family subscription</span><strong>₹200 / month · separate</strong></div><div className="modal-detail-row"><span>Caregiver subscription</span><strong>₹200 / month · separate</strong></div><p className="modal-charge-note">Subscriptions and service charges are separate. No payment is taken here; all final fees and applicable taxes must be disclosed before launch.</p></div><button type="button" className="button button-primary full-width" onClick={() => setBookingDone(true)}>Show demo booking acknowledgement <ArrowRight size={16} /></button><p className="modal-fine-print">This action stays in your browser. It does not create a real booking or send patient or caregiver information.</p>
      </>}</section></div>}
    </div>
  );
}
