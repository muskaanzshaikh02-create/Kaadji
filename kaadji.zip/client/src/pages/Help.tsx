import { useState } from "react";
import { AlertTriangle, ArrowRight, Check, Clock3, HeartHandshake, LifeBuoy, ShieldAlert, Sparkles } from "lucide-react";

const categories = ["Caregiver non-arrival", "Replacement request", "Poor service or unprofessional behaviour", "Payment or refund dispute", "Harassment or inappropriate conduct", "Safety concern", "Booking problem", "Verification concern", "Other complaint"];

export default function Help() {
  const [submitted, setSubmitted] = useState(false);
  const [issue, setIssue] = useState(categories[0]);
  const [priority, setPriority] = useState("Standard");
  const [ticketId] = useState(() => `KJ-DEMO-${Math.floor(1000 + Math.random() * 9000)}`);
  const [ticketTime, setTicketTime] = useState<string | null>(null);
  return <div className="page-wrap inner-page">
    <div className="page-intro"><span className="section-kicker">Support and replacement concept</span><h1>When plans change, the next step should be clear.</h1><p>Use this demo to see how a concern or replacement request could be recorded and coordinated.</p></div>
    <div className="support-live-warning"><div className="warning-icon"><AlertTriangle size={21} /></div><div><strong>Prototype only — no live support is available here.</strong><p>A genuine 24/7 grievance and replacement service requires an actual staffed or on-call team. Kaadji support is not an emergency or medical service, and immediate replacement cannot be guaranteed.</p></div></div>
    <div className="help-layout">
      <section className="ticket-card"><div className="ticket-card-head"><div className="ticket-heading-icon"><HeartHandshake size={21} /></div><div><span className="section-kicker">Raise a demo ticket</span><h2>Tell us what happened</h2></div></div>{submitted ? <div className="ticket-success"><span className="success-icon"><Check size={22} /></span><span className="section-kicker">Local demo confirmation</span><h2>Ticket {ticketId}</h2><p>This reference exists only on this screen. Nothing was sent or saved.</p><div className="ticket-status-box"><div><span>Created at</span><strong>{ticketTime}</strong></div><div><span>Issue type</span><strong>{issue}</strong></div><div><span>Priority</span><strong>{priority}</strong></div><div><span>Assigned operator</span><strong>Sample queue — not live</strong></div><div><span>Status</span><strong>Acknowledged in demo</strong></div><div><span>Communication / resolution history</span><strong>Would be recorded in a live case</strong></div></div><button className="button button-outline" onClick={() => setSubmitted(false)}>Back to form</button></div> : <form onSubmit={(event) => { event.preventDefault(); setTicketTime(new Date().toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short", timeZone: "Asia/Kolkata" })); setSubmitted(true); }} className="form-stack">
      <label className="field-block"><span>What do you need help with?</span><select value={issue} onChange={(event) => setIssue(event.target.value)}>{categories.map((category) => <option key={category}>{category}</option>)}</select></label>
      <label className="field-block"><span>Booking ID (optional)</span><input placeholder="Prototype example only" /></label>
      <label className="field-block"><span>Priority</span><select value={priority} onChange={(event) => setPriority(event.target.value)}><option>Standard</option><option>Urgent — demonstration only</option></select></label>
      <label className="field-block"><span>What would you like the team to know?</span><textarea rows={4} placeholder="Please do not enter real health, payment or identifying information in this demo." /></label>
      <div className="privacy-callout"><ShieldAlert size={18} /><p>For the prototype, keep details fictional. A live service would restrict access, record a timestamp, priority, assigned operator, status, communication history and resolution.</p></div>
      <button className="button button-primary" type="submit">Show sample acknowledgement <ArrowRight size={17} /></button>
    </form>}</section>
      <aside className="help-aside"><div className="aside-icon"><LifeBuoy size={23} /></div><span className="section-kicker">What a live process should do</span><h2>Support with follow-through.</h2><div className="support-process-list"><div><span>01</span><p>Create a priority ticket and notify the support team.</p></div><div><span>02</span><p>Review urgency and search for an approved, suitable alternative.</p></div><div><span>03</span><p>Get family confirmation before assigning a replacement.</p></div><div><span>04</span><p>Update the booking and record the resolution.</p></div></div><div className="support-sla-note"><Clock3 size={16} /><p>Acknowledgement targets such as 30–60 minutes are operational goals only where staffing makes them feasible—not a guarantee.</p></div><div className="emergency-callout"><AlertTriangle size={18} /><div><strong>Immediate danger?</strong><p>In India, call <b>112</b> for emergency assistance. Do not wait for an app response.</p></div></div><p className="tiny-disclaimer"><Sparkles size={13} /> No ticket in this prototype reaches a real operator.</p></aside>
    </div>
  </div>;
}
