import { useState } from "react";
import { ArrowRight, ArrowUpRight, BadgeCheck, CalendarDays, Heart, House, MapPin, ShieldCheck, Sparkles } from "lucide-react";
import { Link } from "wouter";
import { useLanguage } from "@/contexts/LanguageContext";
import PortraitPlaceholder from "@/components/PortraitPlaceholder";
import { demoCaregivers } from "@shared/demo-data";

export default function Home() {
  const { t } = useLanguage();
  const [setting, setSetting] = useState<"home" | "hospital">("home");
  const [location, setLocation] = useState("");

  return (
    <>
      <section className="hero-section page-wrap">
        <div className="hero-copy">
          <div className="eyebrow"><span className="eyebrow-dot" />{t("heroEyebrow")}</div>
          <h1>{t("heroTitle")}</h1>
          <p className="hero-lede">{t("heroBody")}</p>
          <div className="hero-actions">
            <Link href="/find-care" className="button button-primary">{t("findButton")} <ArrowRight size={18} /></Link>
            <Link href="/become-caregiver" className="button button-outline">{t("joinButton")} <ArrowUpRight size={17} /></Link>
          </div>
          <div className="hero-assurance"><ShieldCheck size={18} /><span>{t("noMedical")}</span></div>
          <span className="prototype-badge"><Sparkles size={13} /> {t("sample")}</span>
        </div>
        <div className="hero-image-wrap hero-scene" role="img" aria-label="Abstract illustration representing companionship and home support">
          <div className="hero-scene-art" aria-hidden="true"><span className="scene-sun" /><span className="scene-arch" /><span className="scene-hill" /><span className="scene-plant" /><span className="scene-quote">Thoughtful care begins with listening.</span></div>
          <div className="hero-note-card"><span className="note-icon"><Heart size={17} fill="currentColor" /></span><div><strong>Care that feels closer.</strong><span>Thoughtful support, shaped around the person.</span></div></div>
          <span className="hero-image-caption">Abstract illustration · no live caregiver photo</span>
        </div>
      </section>

      <section className="quick-search-section page-wrap" aria-labelledby="quick-search-title">
        <div className="quick-search-heading">
          <div><span className="section-kicker">A simple place to begin</span><h2 id="quick-search-title">What kind of support do you need?</h2></div>
          <p>Choose a care setting and location. This prototype does not check live caregiver availability.</p>
        </div>
        <div className="quick-search-card">
          <div className="setting-options" role="group" aria-label={t("careChoice")}>
            <button type="button" className={setting === "home" ? "setting-option selected" : "setting-option"} onClick={() => setSetting("home")} aria-pressed={setting === "home"}><House size={20} /><span>{t("homeCare")}</span></button>
            <button type="button" className={setting === "hospital" ? "setting-option selected" : "setting-option"} onClick={() => setSetting("hospital")} aria-pressed={setting === "hospital"}><Heart size={20} /><span>{t("hospitalCare")}</span></button>
          </div>
          <label className="field-block location-field"><span>{t("locationLabel")}</span><div className="input-with-icon"><MapPin size={18} /><input value={location} onChange={(event) => setLocation(event.target.value)} placeholder={t("locationPlaceholder")} /></div></label>
          <Link href={`/find-care?setting=${setting}${location ? `&location=${encodeURIComponent(location)}` : ""}`} className="button button-primary search-button">Explore care <ArrowRight size={18} /></Link>
        </div>
        <div className="search-footnote"><ShieldCheck size={16} /><span>We only ask for the details needed to help plan a care request.</span></div>
      </section>

      <section className="care-path-section page-wrap">
        <div className="section-heading-row"><div><span className="section-kicker">Two ways to find support</span><h2>Care, where it’s needed</h2></div><Link href="/how-it-works" className="text-link">How it works <ArrowRight size={16} /></Link></div>
        <div className="care-path-grid">
          <Link href="/find-care?setting=home" className="care-path-card home-path"><div className="path-icon"><House size={22} /></div><span className="path-label">01 · AT HOME</span><h3>Support in familiar surroundings</h3><p>Companionship and day-to-day assistance, planned around the person and family.</p><span className="path-arrow"><ArrowUpRight size={19} /></span></Link>
          <Link href="/find-care?setting=hospital" className="care-path-card hospital-path"><div className="path-icon"><Heart size={22} /></div><span className="path-label">02 · IN HOSPITAL</span><h3>A steady presence by the bedside</h3><p>Non-clinical companionship and daily-living assistance, subject to hospital policy.</p><span className="path-arrow"><ArrowUpRight size={19} /></span></Link>
        </div>
        <p className="clinical-note">Kaadji is not a substitute for clinical nursing or emergency medical care.</p>
      </section>

      <section className="caregiver-preview-section page-wrap">
        <div className="section-heading-row"><div><span className="section-kicker">Designed for trust, not guesswork</span><h2>See what a caregiver profile will include</h2></div><Link href="/find-care" className="text-link">Explore the demo <ArrowRight size={16} /></Link></div>
        <div className="sample-disclaimer"><Sparkles size={15} /><span>Every example below is illustrative. No caregiver, verification, review or availability is live.</span></div>
        <div className="preview-profile-grid">
          {demoCaregivers.map((profile) => <article className="preview-profile-card" key={profile.id}>
            <div className="preview-profile-photo"><PortraitPlaceholder variant={profile.id} photoPath={profile.photoPath} label={`Fictional AI-generated sample portrait for ${profile.name}; not a real caregiver`} /><span className="profile-demo-chip">Fictional sample</span></div>
            <div className="preview-profile-content"><div className="profile-name-row"><h3>{profile.name}</h3><BadgeCheck size={17} className="badge-muted" aria-label="Verification is not live" /></div><p className="profile-role">{profile.skills.slice(0, 2).join(" · ")} · {profile.city} · sample area</p><div className="profile-facts"><span>{profile.years} years' experience · sample</span><span>{profile.settings.join(" · ")}</span></div><div className="profile-footer"><span className="no-reviews">No eligible reviews</span><span className="sample-price">₹{profile.priceInr} <small>proposed / 24 hours*</small></span></div></div>
          </article>)}
        </div>
        <p className="price-footnote">* Proposed service price only. The 24-hour arrangement and working conditions must be defined before launch.</p>
      </section>

      <section className="home-join-band page-wrap"><div className="join-band-inner"><div><span className="section-kicker">For people who care</span><h2>Bring your experience to a family that needs support.</h2><p>Share your skills, preferred locations and availability through a guided application.</p></div><Link href="/become-caregiver" className="button button-light">{t("joinButton")} <ArrowRight size={17} /></Link></div></section>

      <section className="home-bottom-note page-wrap"><div className="bottom-note-icon"><CalendarDays size={21} /></div><div><h2>Care should be clear from the first step.</h2><p>Compare needs, schedule and terms before a family requests care. No hidden charges and no silent activation.</p></div><Link href="/how-it-works" className="button button-outline">See the steps <ArrowRight size={17} /></Link></section>
    </>
  );
}
