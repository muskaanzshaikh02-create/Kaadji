import { ShieldCheck, Smartphone, Sparkles } from "lucide-react";
import { Link } from "wouter";
import { useLanguage } from "@/contexts/LanguageContext";

export default function Login() {
  const { t } = useLanguage();
  return <div className="page-wrap inner-page login-page">
    <section className="login-card"><div className="login-icon"><Smartphone size={24} /></div><span className="section-kicker">{t("demoLogin")}</span><h1>Your account, when you’re ready.</h1><p>In a live Kaadji service, you would use a verified mobile number and OTP. This prototype does not send a code or create an account.</p><label className="field-block"><span>Mobile number · example only</span><input type="tel" inputMode="tel" placeholder="Enter a sample number — do not use a real one" disabled /></label><button className="button button-primary full-width" type="button" disabled>OTP sign-in unavailable in prototype</button><div className="login-prototype-note"><Sparkles size={15} /><span>Nothing entered here is sent or stored.</span></div><div className="login-roles"><Link href="/find-care">Explore patient/family demo</Link><Link href="/become-caregiver">Explore caregiver demo</Link><Link href="/operator">Open operator concept</Link></div><div className="privacy-callout"><ShieldCheck size={18} /><p>Production accounts will have role-based access, least-privilege staff permissions and privacy notices before sensitive information is requested.</p></div></section>
  </div>;
}
