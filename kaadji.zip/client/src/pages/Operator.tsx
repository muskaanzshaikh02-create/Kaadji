import { Activity, AlertCircle, ArrowDownRight, ArrowUpRight, BadgeCheck, CalendarDays, CheckCircle2, Clock3, CreditCard, FileCheck2, FileText, HeartHandshake, MapPin, MessageSquareWarning, RotateCcw, Search, ShieldCheck, Users, Wallet } from "lucide-react";

const metrics = [
  { label: "Registered patients / families", value: "128", note: "sample total", icon: Users, trend: "+8 this week · sample" },
  { label: "Registered caregivers", value: "64", note: "sample total", icon: HeartHandshake, trend: "+4 this week · sample" },
  { label: "Pending verification", value: "9", note: "sample queue", icon: FileCheck2, trend: "3 need attention · sample" },
  { label: "Approved & available", value: "27", note: "sample only", icon: BadgeCheck, trend: "capacity not live" },
  { label: "New booking requests", value: "12", note: "sample queue", icon: CalendarDays, trend: "5 awaiting reply · sample" },
  { label: "Confirmed bookings", value: "21", note: "sample total", icon: CheckCircle2, trend: "not live bookings" },
  { label: "Active assignments", value: "18", note: "sample total", icon: Activity, trend: "not live bookings" },
  { label: "Completed bookings", value: "86", note: "sample total", icon: CheckCircle2, trend: "not live bookings" },
  { label: "Cancelled bookings", value: "7", note: "sample total", icon: RotateCcw, trend: "not live bookings" },
  { label: "Subscription payments", value: "₹25,600", note: "sample only", icon: Wallet, trend: "no real transactions" },
  { label: "Refunds / payment issues", value: "3", note: "sample queue", icon: CreditCard, trend: "sample only" },
  { label: "Open grievances", value: "4", note: "sample queue", icon: MessageSquareWarning, trend: "1 marked urgent · sample" },
  { label: "Replacement requests", value: "2", note: "sample queue", icon: RotateCcw, trend: "not live" },
  { label: "Response / resolution", value: "—", note: "sample SLA view", icon: Clock3, trend: "no service metrics" },
  { label: "Demand by city / PIN", value: "—", note: "sample report view", icon: MapPin, trend: "no live location data" },
];
const sections = ["Overview", "Users", "Caregivers", "Verification", "Bookings", "Subscriptions", "Payments & refunds", "Reviews", "Grievances", "Replacements", "Notifications", "Reports"];
const queue = [
  { id: "KJ-DEMO-1042", title: "Replacement request", location: "Pune · sample location", priority: "Urgent · sample", status: "Needs review", time: "10 min ago · sample" },
  { id: "KJ-DEMO-1037", title: "Additional information required", location: "Mumbai · sample location", priority: "Standard · sample", status: "Waiting for caregiver", time: "42 min ago · sample" },
  { id: "KJ-DEMO-1028", title: "Caregiver non-arrival", location: "Nashik · sample location", priority: "Urgent · sample", status: "Operator assigned", time: "1 hr ago · sample" },
];

export default function Operator() {
  return <div className="operator-page page-wrap">
    <div className="operator-topline"><div><span className="section-kicker">Kaadji operations</span><h1>Daily service overview</h1><p>Role-based admin concept · all records and metrics are fictional sample data.</p></div><div className="operator-user"><div className="operator-user-avatar">K</div><div><strong>Demo operator</strong><span>Support role · illustrative</span></div></div></div>
    <div className="operator-sample-banner"><AlertCircle size={17} /><span>Prototype dashboard — no live data, access control, payment records or operational queues.</span></div>
    <div className="operator-layout">
      <aside className="operator-sidebar"><span className="sidebar-label">WORKSPACE</span>{sections.map((section, index) => <button type="button" className={index === 0 ? "operator-nav active" : "operator-nav"} key={section}><span className="operator-nav-icon">{index === 0 ? <Activity size={16} /> : index === 3 ? <FileCheck2 size={16} /> : index === 8 ? <MessageSquareWarning size={16} /> : index === 9 ? <RotateCcw size={16} /> : <FileText size={16} />}</span>{section}{section === "Grievances" && <i className="nav-count">4</i>}</button>)}<div className="sidebar-role-note"><ShieldCheck size={16} /><span>Production access should be limited by staff role and responsibility.</span></div></aside>
      <div className="operator-main">
        <div className="operator-toolbar"><div className="operator-search"><Search size={16} /><input aria-label="Search sample records" placeholder="Search booking, user, caregiver, location…" /></div><button type="button" className="date-range-button"><CalendarDays size={15} /> Last 7 days <ArrowDownRight size={14} /></button></div>
        <div className="metric-grid">{metrics.map(({ label, value, note, icon: Icon, trend }) => <article className="metric-card" key={label}><div className="metric-card-top"><span>{label}</span><Icon size={17} /></div><strong className="metric-value">{value}</strong><div className="metric-note"><span>{note}</span><span className={trend.startsWith("+") ? "metric-trend positive" : "metric-trend"}>{trend}</span></div></article>)}</div>
        <div className="operator-content-grid">
          <section className="operator-panel"><div className="panel-heading"><div><span className="section-kicker">Support queue · sample</span><h2>Cases to review</h2></div><button type="button" className="panel-link">View all <ArrowUpRight size={15} /></button></div><div className="sample-case-list">{queue.map((item) => <article className="sample-case" key={item.id}><div className="case-priority-icon"><MessageSquareWarning size={17} /></div><div className="case-main"><strong>{item.title}</strong><span>{item.id} · {item.location}</span><small>{item.time}</small></div><div className="case-status"><span className="status-pill urgent-pill">{item.priority}</span><span>{item.status}</span></div></article>)}</div><p className="table-note">These examples illustrate ticket timestamps, priority, assignment and status only.</p></section>
          <section className="operator-panel verification-panel"><div className="panel-heading"><div><span className="section-kicker">Caregiver checks · sample</span><h2>Verification queue</h2></div><FileCheck2 size={18} /></div><div className="verification-summary"><div><span>Identity review</span><strong>6 <small>sample</small></strong></div><div><span>Qualification check</span><strong>3 <small>sample</small></strong></div></div><div className="verification-note"><ShieldCheck size={16} /><p>Keep identity verification distinct from professional qualification review. Only approved profiles should be labelled verified.</p></div><button className="button button-outline full-width" type="button">Open sample queue</button></section>
        </div>
        <section className="operator-panel booking-panel"><div className="panel-heading"><div><span className="section-kicker">Booking activity · sample</span><h2>Recent requests</h2></div><div className="booking-legend"><span><i className="legend-dot requested" /> Requested</span><span><i className="legend-dot confirmed" /> Confirmed</span><span><i className="legend-dot active" /> Active</span></div></div><div className="booking-table-wrap"><table className="booking-table"><thead><tr><th>Booking ID</th><th>Care type</th><th>City</th><th>Caregiver</th><th>Price</th><th>Status</th></tr></thead><tbody><tr><td>KJ-DEMO-2084</td><td>Home care</td><td>Pune</td><td>Sample caregiver A</td><td>₹400*</td><td><span className="booking-status requested">Requested</span></td></tr><tr><td>KJ-DEMO-2079</td><td>Hospital care</td><td>Mumbai</td><td>Sample caregiver B</td><td>₹400*</td><td><span className="booking-status confirmed">Confirmed · sample</span></td></tr><tr><td>KJ-DEMO-2072</td><td>Home care</td><td>Nashik</td><td>Sample caregiver C</td><td>₹400*</td><td><span className="booking-status active">In progress · sample</span></td></tr></tbody></table></div><p className="table-note">* Proposed rate for a defined 24-hour arrangement; not a final price or actual transaction.</p></section>
      </div>
    </div>
  </div>;
}
