import { lazy, Suspense } from "react";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import SiteLayout from "./components/SiteLayout";
import { LanguageProvider } from "./contexts/LanguageContext";
import { ThemeProvider } from "./contexts/ThemeContext";
const Home = lazy(() => import("./pages/Home"));
const FindCare = lazy(() => import("./pages/FindCare"));
const BecomeCaregiver = lazy(() => import("./pages/BecomeCaregiver"));
const HowItWorks = lazy(() => import("./pages/HowItWorks"));
const Help = lazy(() => import("./pages/Help"));
const Operator = lazy(() => import("./pages/Operator"));
const Login = lazy(() => import("./pages/Login"));

function Router() {
  return (
    <LanguageProvider>
      <SiteLayout>
        <Suspense fallback={<div className="page-wrap inner-page" role="status">Loading page…</div>}>
          <Switch>
            <Route path="/" component={Home} />
            <Route path="/find-care" component={FindCare} />
            <Route path="/become-caregiver" component={BecomeCaregiver} />
            <Route path="/how-it-works" component={HowItWorks} />
            <Route path="/help" component={Help} />
            <Route path="/operator" component={Operator} />
            <Route path="/login" component={Login} />
            <Route path="/404" component={NotFound} />
            <Route component={NotFound} />
          </Switch>
        </Suspense>
      </SiteLayout>
    </LanguageProvider>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
