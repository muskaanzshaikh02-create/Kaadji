import { createContext, useContext, useMemo, useState, type ReactNode } from "react";

type Language = "en" | "mr";

const copy = {
  en: {
    home: "Home",
    findCare: "Find Care",
    becomeCaregiver: "Become a Caregiver",
    howItWorks: "How It Works",
    help: "Help & Support",
    login: "Log in",
    findButton: "Find a Caregiver",
    joinButton: "Join as a Caregiver",
    heroEyebrow: "Care, with a little more closeness",
    heroTitle: "Kaadji — Care That Comes Closer to Home.",
    heroBody: "Find trusted care for your loved ones, at home or in the hospital.",
    locationLabel: "Where is care needed?",
    locationPlaceholder: "City or PIN code",
    careChoice: "Choose a care setting",
    homeCare: "Home care",
    hospitalCare: "Hospital care",
    support: "24/7 Help & Replacement",
    supportNotLive: "Prototype only · support is not live",
    sample: "Illustrative prototype only",
    noMedical: "Non-clinical caregiving only. Regulated nursing is shown only when appropriately qualified and authorised.",
    demoLogin: "Prototype sign-in",
    language: "मराठी",
  },
  mr: {
    home: "मुख्यपृष्ठ",
    findCare: "मदत शोधा",
    becomeCaregiver: "केअरगिव्हर बना",
    howItWorks: "हे कसे कार्य करते",
    help: "मदत व सहाय्य",
    login: "लॉग इन",
    findButton: "केअरगिव्हर शोधा",
    joinButton: "केअरगिव्हर म्हणून सामील व्हा",
    heroEyebrow: "काळजी, तुमच्या अधिक जवळ",
    heroTitle: "Kaadji — काळजी आता तुमच्या घराजवळ.",
    heroBody: "तुमच्या प्रियजनांसाठी घरात किंवा रुग्णालयात विश्वासार्ह मदत शोधा.",
    locationLabel: "मदत कुठे हवी आहे?",
    locationPlaceholder: "शहर किंवा पिन कोड",
    careChoice: "सेवेचा प्रकार निवडा",
    homeCare: "घरची काळजी",
    hospitalCare: "रुग्णालयातील मदत",
    support: "२४/७ मदत व पर्यायी केअरगिव्हर",
    supportNotLive: "फक्त प्रोटोटाइप · प्रत्यक्ष सहाय्य उपलब्ध नाही",
    sample: "फक्त उदाहरणासाठीचे प्रोटोटाइप",
    noMedical: "फक्त गैर-वैद्यकीय देखभाल. आवश्यक पात्रता व परवानगी असल्याशिवाय वैद्यकीय परिचर्या सेवा दाखवली जाणार नाही.",
    demoLogin: "प्रोटोटाइप लॉग इन",
    language: "English",
  },
} satisfies Record<Language, Record<string, string>>;

type CopyKey = keyof typeof copy.en;

const LanguageContext = createContext<{
  language: Language;
  toggleLanguage: () => void;
  t: (key: CopyKey) => string;
} | null>(null);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("en");
  const value = useMemo(
    () => ({
      language,
      toggleLanguage: () => setLanguage((current) => (current === "en" ? "mr" : "en")),
      t: (key: CopyKey) => copy[language][key],
    }),
    [language],
  );

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  const value = useContext(LanguageContext);
  if (!value) throw new Error("useLanguage must be used within LanguageProvider");
  return value;
}
