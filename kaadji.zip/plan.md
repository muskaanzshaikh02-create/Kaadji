# Kaadji — Product Concept, Architecture, Budget & Delivery Plan

**Status:** Approved web and Android prototypes delivered; full production development remains unapproved.
**Current stage:** The responsive web prototype is available in Preview, and the separate Expo/React Native Android prototype passed TypeScript validation and Android bundle export. Browser smoke checks verified five photo-backed fictional profiles, a Nashik search result, caregiver details and a privacy-minimized patient summary. No backend, database, real authentication/OTP, payment integration, personal-data persistence, production security controls, or public deployment is included.

## 1. Approved scope and next decision

The user approved the Phase 0 clickable web prototype and subsequently requested an **Android app prototype**. Both use clearly marked fictional content and local interactions; they do not register users, accept payments, store real health information, claim live caregiver availability, or provide operational support. Full product development remains paused until separate approval after review.

The user has now supplied `KaadjiWellnessLogo.png`. Use this original image and its cream, deep-green, sage and coral palette in the web and Android prototypes; do not redraw, replace or alter the mark. The Phase 0 scope now includes both the responsive web prototype and the native Android prototype; the production Android app estimate below remains for full implementation, not this local prototype.

## 2. Phase 0 UI/UX prototype

### Landing page

The first screen uses the required headline, **“Kaadji — Care That Comes Closer to Home.”** Supporting copy: **“Find trusted care for your loved ones, at home or in the hospital.”** The two primary, high-contrast actions are **“Find a Caregiver”** and **“Join as a Caregiver.”** The top navigation is Home, Find Care, Become a Caregiver, How It Works, Help and Support, and Login. A persistent support entry is visible, with a clear emergency note rather than a promise that a staffed 24/7 service already exists.

The visual direction is calm and human rather than clinical: a warm off-white canvas, deep teal accents, restrained terracotta highlights, large readable type, generous spacing, clear service-category choices, and simple language. The first screen will orient users before asking them to fill in details.

### Clickable paths and screens

1. **Find care:** choose Home Care or Hospital Care; enter a city or PIN code; describe the type of non-clinical assistance; choose a date, start time, and duration; review illustrative caregiver cards; see a transparent provisional price breakdown; and submit a demo booking request that ends in a prototype confirmation state.
2. **Caregiver discovery:** a filterable demonstration list and profile detail showing fields the production product needs: identity/verification state, relevant experience, skills, languages, service areas, care-type eligibility, availability, eligible review count, price, and introduction. Every card will say **“Illustrative prototype profile — not a real caregiver; availability and verification are not live.”** No fabricated testimonials or ratings will be presented as genuine.
3. **Join as a caregiver:** a short, staged application concept for contact and work details, service areas, languages, experience, skills, availability, documents, and emergency contact. Status examples cover Application Submitted, Verification Pending, Additional Information Required, Approved, Rejected, and Temporarily Suspended; all will be marked illustrative.
4. **Operator view:** a role-separated dashboard concept for verification, bookings, subscriptions/payments, reviews, grievances, replacements, and reports. Any displayed counts or records will be labelled sample data. No real sensitive data will be used.
5. **Help and replacement:** a demonstration ticket form with issue type, urgency, booking reference, and acknowledgement state. It will explain that a genuine 24/7 service depends on actual staffing or an on-call arrangement and that support does not replace emergency medical services. Emergency guidance will identify India's 112 number where appropriate.
6. **How it works and pricing:** clear home-care versus hospital-care explanations, a non-clinical-care boundary, and the two proposed price concepts: ₹200/month for each patient/family and caregiver subscription, and ₹400 for a proposed 24-hour arrangement. The latter will be labelled **provisional** until attendance, rest/sleep, duties, handovers, meals, transport, extensions, staffing, and lawful working conditions are defined.

Prototype interactions include navigation, service-type selection, searchable/filterable fictional profiles, caregiver details, a match view showing the selected caregiver plus a non-identifying care-request summary, staged forms, demo success states, and support-ticket entry. The care summary may show care setting, requested non-clinical needs, general area and schedule. Patient name, phone, exact address and sensitive health notes remain hidden until a real booking is confirmed and explicit consent is recorded; because this prototype has no real booking or patient records, those private details never appear. There will be no live OTP, uploads, payment, real booking, true availability check, or administrator access control in this phase.

The web and Android demonstrations will each contain five distinct fictional caregiver examples with generated photorealistic portraits and realistic sample attributes. Label each image/profile as fictional sample data; do not imply that a person, credential, review, verification, availability, patient, or booking is real.

### Design direction

Three possible directions were considered: **Quiet Indian editorial warmth** (0.06), **Neighbourhood care journal** (0.04), and **Minimal service desk** (0.03). I recommend Quiet Indian editorial warmth: contemporary, reassuring, and dignified without looking like a hospital portal or a crowded marketplace.

- **Core principles:** humane and calm; disclose what is verified and what is not; make the next step obvious; keep forms and words accessible to older adults.
- **Palette:** use the supplied logo's warm ivory, deep green, sage and coral colours for trust, calm and warmth; keep text contrast and accessibility high.
- **Layout:** a clear editorial landing hero, followed by a guided care-choice panel and selectively surfaced caregiver examples; compact, task-focused dashboard sections; responsive single-column flows on mobile.
- **Signature elements:** gentle rounded panels; a simple location/service-type marker; restrained status chips that distinguish “verification pending” from “verified.”
- **Interaction and motion:** large touch targets, visible focus, plain-language help, reduced-motion support, short transitions only where they clarify state changes.
- **Typography:** a legible sans-serif family with Devanagari coverage for Marathi/Hindi; final font selection will be checked for language rendering and licensing.
- **Brand essence:** dependable local care for families and caregivers; **warm, clear, responsible**.
- **Voice examples:** “Choose the kind of support you need.” “Not sure where to begin? Ask our team to help you plan a request.”
- **Logo and wordmark:** use the supplied Kaadji mark as supplied, preserving its proportions; do not create a substitute mark.
- **Signature colours:** deep logo green and warm coral, supported by sage and ivory.

## 3. Recommended technical architecture

### MVP stack

The initialized web project uses the WebDev `web-db-user` starter: React, TypeScript, Tailwind, Express, tRPC, Drizzle, and MySQL. It suits a cost-conscious MVP because the browser experience and API can be maintained in one TypeScript codebase, and the existing starter already separates frontend, API, schema, and migration responsibilities.

For the first clickable prototype, keep it static and disable server/database resources. Once the prototype and this architecture are approved, enable a backend and managed relational database only when implementation begins. Do not build production authentication around the starter's default OAuth: the brief requires mobile-number OTP. Select an India-capable OTP provider and implement OTP expiry, retry limits, rate limits, consent, and abuse controls after provider and cost approval.

For the approved Android prototype, use a distinct Expo/React Native TypeScript app under `mobile/`, separate from the web app but in the same source repository, with local fictional sample data and no backend calls. This is a native Android prototype, not a web page presented as an app. A future production Android app should call the same authenticated API and database as the web product; production Android/backend implementation remains subject to separate approval.

### Production component map

```mermaid
flowchart LR
  P[Patient and family web] --> API[Authenticated application API]
  C[Caregiver web] --> API
  O[Operator console] --> API
  A[Android app] --> API
  API --> AUTH[Mobile OTP authentication and role access]
  API --> DB[(Relational MySQL database)]
  API --> OBJ[Private document and image storage]
  API --> PAY[Indian payment gateway]
  API --> MSG[SMS, email, optional WhatsApp and push]
  API --> AUD[Audit, booking and ticket event history]
```

Production API modules should separate users/roles, patient profiles, caregiver profiles and verification, location coverage, availability, bookings, subscriptions, payment/refunds, reviews, grievances/replacements, notifications, and audit reporting. Use provider webhooks with signature verification for payment state changes. Store provider transaction references and status, not card numbers, CVV, or UPI PINs. Keep platform subscriptions separate from caregiver service payments, refunds, taxes, and any later commission.

### Project structure proposal

- `client/src/pages/` — landing, find-care, caregiver application, help, and later role dashboards.
- `client/src/components/` — shared navigation, accessible controls, caregiver cards, status labels, and form components.
- `client/src/features/` — focused patient, caregiver, booking, support, and operator UI modules as they become functional.
- `server/routers.ts` and `server/` — typed API routes and business services after backend approval.
- `drizzle/schema.ts` and `drizzle/` — relational schema and reviewed database migrations after database approval.
- `server/storage.ts` — private document/object-storage access policies and signed download flows.
- `docs/` — privacy and retention policy, security notes, deployment guide, operator guide, and pricing/service terms.
- `mobile/` — standalone Expo/React Native Android prototype with its own app entry, screens and locally bundled logo/fictional demo assets; no production API or patient records.

## 4. Database plan

Use MySQL with generated numeric or UUID keys, explicit foreign keys, created/updated timestamps, status history, and indexes for phone number, booking ID, caregiver/location/date, payment reference, ticket priority/status, and date-based operator search. Store all scheduling instants consistently and display them in `Asia/Kolkata`.

| Entity group | Planned records and relationships |
| --- | --- |
| Identity and access | `users` (unique phone, consent and account state), role assignments, staff permission scopes, login/OTP attempt metadata with short retention; a person may hold multiple permitted roles. |
| Patient and family | `patient_profiles`, authorised family relationships, patient/dependent records, service addresses and location IDs; care instructions kept in a separately protected record with purpose/consent and least-privilege access. |
| Caregiver and verification | `caregiver_profiles`, skills/languages/qualifications, service areas, availability slots, verification cases, document metadata, reviewer decisions and application status history. Identity checks and professional qualification checks remain distinct. |
| Coverage and booking | Activated cities/PIN codes, `bookings`, requirements, selected service type, schedule/duration, price snapshot, assigned caregiver, booking status, cancellations/reschedules, and append-only `booking_events`. Use database transactions/unique constraints or equivalent locking so overlapping assignments cannot be confirmed. |
| Subscription and money | `subscriptions` (one standard ₹200/month plan per eligible account), payment attempts/transactions, provider references, receipts, refunds, caregiver payout records where applicable, and reconciliation events. Keep subscription transactions separate from service transactions. |
| Trust and support | Eligible `reviews` linked to completed bookings; reports/moderation; `grievance_tickets`, replacement request details, assignment/escalation, priority, acknowledgement/resolution timestamps, message/event history, and closure outcome. |
| Operations and governance | In-app/SMS/email notification records, consent and privacy acknowledgements, city/PIN activation, configurable rate/service settings, and immutable-style `admin_audit_logs` for sensitive staff actions. |

Patient/caregiver residential addresses and care notes must not appear in public profiles. Expose the minimum assignment details only to authorised parties at the correct booking stage. Secure uploads in private object storage; store file metadata and access decisions in the database, not public document URLs. Set retention/deletion rules after India privacy/legal review. Do not seed fake information into production.

## 5. Safety, policy, and launch constraints

- The product must distinguish non-clinical caregiving from regulated nursing. Clinical tasks are shown only for appropriately qualified and authorised professionals, where legally permitted.
- Do not display “verified” until the required checks have been reviewed and approved. Keep identity verification separate from credential checks.
- Do not suggest that coverage is active in every target Maharashtra city. Operators activate cities/PIN codes only when actual capacity exists.
- The ₹400 proposed 24-hour price cannot be treated as final until duties, attendance, rest/sleep time, handovers, meals, transport, extensions, staffing, and applicable working conditions are defined. One caregiver must not be assumed to work continuously without rest. Obtain local legal/operations review before advertising this unit or price.
- The 24/7 grievance and replacement feature requires a real staffing/on-call plan, not just a button and ticket software. An always-covered single live seat represents 168 staffed hours weekly, or 4.2 full-time 40-hour positions before leave and overlap; a practical roster needs additional cover. Staffing cost is not included in the software estimate below. Do not promise immediate replacement where availability is uncertain.
- Keep the ₹200 monthly subscription a single standard plan for families and caregivers; show its terms, renewal, expiry, payment status, receipts, failure and refund/cancellation policy before payment. Keep it separate from service charges.
- Do not create fake reviews, testimonials, verification states, or availability. Use only clearly labelled prototype records until genuine bookings support real reviews.
- Complete India legal, tax, consumer-protection, data-protection, payment, employment, safeguarding, and insurance review before launch. This plan is not legal advice.

## 6. Indicative itemised budget

These are **planning estimates**, not a vendor quotation or a fixed bid. The range assumes a small India-based delivery team, one standard Android app and responsive web product, Phase 1 MVP scope, and reuse of the initialized TypeScript starter. It excludes GST/taxes on development invoices, major scope changes, legal opinions, caregiver wages, background-check charges, insurance, 24/7 customer-support staffing, and the cost of operating the care service.

| One-time work item | Planning range (INR) |
| --- | ---: |
| Phase 0 clickable prototype (responsive web + Expo Android companion, included below; 1–2 weeks) | ₹0.60–1.00 lakh |
| Product discovery, service rules, UX/UI and accessible design | ₹1.20–1.80 lakh |
| Responsive patient/family, caregiver and operator web application | ₹3.50–5.00 lakh |
| Android application (Expo/React Native) | ₹3.00–5.00 lakh |
| Backend, OTP auth, roles, schema, private storage and audit foundations | ₹3.00–4.50 lakh |
| Booking, availability/conflict prevention, grievance and replacement flows | ₹2.00–3.00 lakh |
| Subscriptions, payment gateway, receipts, refund and reconciliation flows | ₹1.00–1.80 lakh |
| QA, accessibility, security review and release preparation | ₹1.50–2.50 lakh |
| Delivery management, documentation and operator handover | ₹1.00–1.50 lakh |
| **Estimated total, including prototype** | **₹16.80–26.10 lakh** |

Keep a further **10–15% contingency** (about ₹1.68–3.92 lakh) until the care model, final screen set, gateway, and verification process are confirmed. Indicative all-in planning envelope with that contingency: **about ₹18.5–30.0 lakh**. Legal, tax, staffing and care operations remain separate.

### Indicative recurring software costs

| Recurring item | Planning allowance or current public price evidence |
| --- | --- |
| Hosting, managed database and backups | Budget ₹4,000–12,000/month for a low-traffic launch, subject to the chosen provider and region. AWS Lightsail's public list price shows a $12/month 2 GB Linux server and a $30/month 2 GB standard managed database; its listed standard database does not include data encryption, so use an encrypted option or another suitable provider and add backups/traffic. Mumbai-region data-transfer allowance is lower than the generic listed bundles. These figures are a benchmark, not a selected deployment [4]. |
| OTP SMS | MSG91 lists ₹0.25/OTP at a 5,000-message tier and ₹0.20 at 27,000, plus 18% GST; 5,000 at the listed ₹0.25 rate is ₹1,475 including GST [2]. Actual provider, DLT setup, delivery and resale terms require confirmation. |
| Transactional SMS | MSG91 lists ₹0.25 at 5,000 and ₹0.18 at 30,000, plus 18% GST [3]. SMS should be limited to necessary service notifications and consented communication. |
| Email, monitoring, storage and domain | Set aside ₹1,000–4,000/month combined for low early usage, plus approximately ₹500–1,500/year for a domain as a planning allowance. Confirm supplier quotes and data-retention needs before procurement. |
| Payment gateway | Razorpay's current pricing page lists a 2.15% platform fee plus GST for the relevant payment methods; it also advertises an introductory offer whose conditions should not be assumed. At the standard listed fee, collecting ₹200 costs about ₹5.07 in fee plus GST; collecting ₹400 costs about ₹10.15, before any other applicable costs [1]. Confirm the merchant's exact pricing and settlement terms before launch. |
| WhatsApp, push and support tooling | Optional; not included in the base run-rate pending channel choice and provider quotations. |
| 24/7 support staffing | Not a software subscription and not included. Requires a separate capacity, roster, training, escalation and cost plan. |

For a low-volume launch, a rough **software-only baseline is ₹6,500–17,500/month**, excluding gateway fees, WhatsApp, tax/accounting, staff, caregiver verification and care delivery. Actual bills depend on active users, OTP/notification volume, file storage, backup retention, region and provider contracts. A 24/7 staffed replacement operation could cost substantially more than this entire software baseline.

## 7. Indicative delivery timeline

The estimate assumes timely decisions, use of the supplied logo, agreed service rules, and no delay in provider onboarding. Provider approval, legal review, or changes to the proposed 24-hour service unit can extend the schedule.

| Window from approval | Outcome |
| --- | --- |
| Weeks 1–2 | Phase 0 responsive web and Expo Android clickable prototypes, design direction, core patient/caregiver/operator paths, and review. No production backend. |
| Weeks 3–4 | Confirm language needs, city coverage rules, verification policy, rate/service definition, privacy/consent wording, operational staffing model and payment/OTP vendors. Full-development gate remains closed until you approve. |
| Weeks 5–8 | Build shared backend, roles, OTP, schema, verification, caregiver profiles, privacy controls and operator foundations after approval. |
| Weeks 7–12 | Build patient/caregiver web flows, search, eligibility and location rules, availability and booking state transitions; develop the full production Android app in parallel after Phase 1 approval. |
| Weeks 11–15 | Implement subscriptions and payment records, reviews, grievances/replacements, notifications, operator actions and reporting. Payment and messaging activation follows provider approval. |
| Weeks 16–20 (allow up to 22) | Integrated QA, accessibility/security remediation, controlled pilot, admin training, documentation and release readiness. No 24/7 public-service claim until staffing is operational. |
| After Phase 1 | Phase 2: multilingual enhancements, automatic reminders, reconciliation/reporting and escalation automation. Phase 3: additional real-capacity locations and advanced workforce/scheduling operations. |

**Expected Phase 1 elapsed time:** roughly 18–22 weeks after full-development approval. The responsive web and Android prototypes are a separate 1–2-week first stage.

## 8. Approval gate and unresolved inputs

The user has approved and received the web and Android prototypes described in Section 2. The next decision is to review them and request changes or separately approve full production development. The backend, database, production Android build, payment integration, public release, and any claims of live care/support remain outside the approved scope.

The supplied Kaadji logo is now incorporated in the prototypes. Before Phase 1, Kaadji must decide the operational definition and lawful staffing model for the ₹400/24-hour proposal, actual launch cities/PIN codes, verification vendors/policy, production privacy/consent flow, and whether the 24/7 cell will be live-staffed or on-call.

## References

[1]: https://razorpay.com/pricing/ "Razorpay Payment Gateway Pricing"
[2]: https://msg91.com/in/pricing/otp "MSG91 OTP Pricing in India"
[3]: https://msg91.com/in/pricing/sms "MSG91 SMS Pricing in India"
[4]: https://aws.amazon.com/lightsail/pricing/ "Amazon Lightsail Pricing"
