export type DemoProfileId = "a" | "b" | "c" | "d" | "e";

export type DemoProfile = {
  id: DemoProfileId;
  name: string;
  city: string;
  pinCode: string;
  area: string;
  years: number;
  skills: string[];
  languages: string[];
  settings: string[];
  intro: string;
  availability: string;
  photoPath: string;
  training: string;
  eligibleReviewCount: number;
  priceInr: number;
};

/**
 * Every person and attribute below is fictional prototype data. The portrait paths
 * point to generated, non-identifying sample images in project-managed storage.
 * Nothing here represents a real person, verification, credential, review, quote,
 * coverage area, booking, or live availability.
 */
export const demoCaregivers: DemoProfile[] = [
  {
    id: "a",
    name: "Meera Deshmukh",
    city: "Pune",
    pinCode: "411038",
    area: "Kothrud",
    years: 5,
    skills: ["Companionship", "Daily living", "Mobility support"],
    languages: ["Marathi", "Hindi"],
    settings: ["Home care", "Hospital care"],
    intro: "Fictional sample profile illustrating a calm, attentive approach to companionship and everyday support.",
    availability: "Illustrative weekday dates · not live",
    photoPath: "/manus-storage/async-images/G6oTA1tl4yEfTDvV6708WZ/image-1.webp",
    training: "No credentials claimed in this prototype",
    eligibleReviewCount: 0,
    priceInr: 400,
  },
  {
    id: "b",
    name: "Sanjay Patil",
    city: "Mumbai",
    pinCode: "400014",
    area: "Dadar",
    years: 8,
    skills: ["Mobility support", "Companionship"],
    languages: ["Marathi", "English"],
    settings: ["Home care"],
    intro: "Fictional sample profile illustrating an experienced companion for planned, non-clinical daily-living assistance.",
    availability: "Illustrative weekend dates · not live",
    photoPath: "/manus-storage/async-images/G6oTA1tl4yEfTDvV6708WZ/image-2.webp",
    training: "No credentials claimed in this prototype",
    eligibleReviewCount: 0,
    priceInr: 400,
  },
  {
    id: "c",
    name: "Farida Shaikh",
    city: "Nashik",
    pinCode: "422005",
    area: "College Road",
    years: 3,
    skills: ["Daily living", "Supervision"],
    languages: ["Hindi", "English"],
    settings: ["Hospital care"],
    intro: "Fictional sample profile illustrating bedside companionship and non-clinical assistance subject to hospital policy.",
    availability: "No illustrative dates shown",
    photoPath: "/manus-storage/async-images/G6oTA1tl4yEfTDvV6708WZ/image-3.webp",
    training: "No credentials claimed in this prototype",
    eligibleReviewCount: 0,
    priceInr: 400,
  },
  {
    id: "d",
    name: "Rajesh Pawar",
    city: "Nagpur",
    pinCode: "440010",
    area: "Dharampeth",
    years: 4,
    skills: ["Companionship", "Daily living"],
    languages: ["Marathi", "Hindi"],
    settings: ["Home care", "Hospital care"],
    intro: "Fictional sample profile illustrating flexible support preferences across the two care settings.",
    availability: "Illustrative dates · not live",
    photoPath: "/manus-storage/async-images/G6oTA1tl4yEfTDvV6708WZ/image-4.webp",
    training: "No credentials claimed in this prototype",
    eligibleReviewCount: 0,
    priceInr: 400,
  },
  {
    id: "e",
    name: "Sunita Jadhav",
    city: "Thane",
    pinCode: "400601",
    area: "Naupada",
    years: 6,
    skills: ["Supervision", "Daily living", "Companionship"],
    languages: ["Marathi", "Hindi", "English"],
    settings: ["Home care"],
    intro: "Fictional sample profile illustrating routine non-clinical support and clear family communication.",
    availability: "Illustrative weekday dates · not live",
    photoPath: "/manus-storage/async-images/G6oTA1tl4yEfTDvV6708WZ/image-5.webp",
    training: "No credentials claimed in this prototype",
    eligibleReviewCount: 0,
    priceInr: 400,
  },
];

export const demoPriceInr = 400;
export const demoMonthlySubscriptionInr = 200;
export const demoPrivacyNotice =
  "Patient identity, phone number, exact address and sensitive health notes stay hidden until a real booking is confirmed and explicit consent is recorded. This prototype has no real patient records, booking or consent flow.";
