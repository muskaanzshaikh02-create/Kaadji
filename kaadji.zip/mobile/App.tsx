import { StatusBar } from "expo-status-bar";
import { useMemo, useState } from "react";
import {
  Image,
  Keyboard,
  Modal,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { demoCaregivers, demoPrivacyNotice, type DemoProfile } from "../shared/demo-data";

const kaadjiLogo = require("./assets/images/KaadjiWellnessLogo.png");
const caregiverPhotos = {
  a: require("./assets/images/caregiver-a.webp"),
  b: require("./assets/images/caregiver-b.webp"),
  c: require("./assets/images/caregiver-c.webp"),
  d: require("./assets/images/caregiver-d.webp"),
  e: require("./assets/images/caregiver-e.webp"),
} as const;

type ChipProps = {
  label: string;
  selected: boolean;
  onPress: () => void;
};

function Chip({ label, selected, onPress }: ChipProps) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected }}
      onPress={onPress}
      style={[styles.chip, selected && styles.chipSelected]}
    >
      <Text style={[styles.chipText, selected && styles.chipTextSelected]}>{label}</Text>
    </Pressable>
  );
}

function CaregiverPortrait({ profile, large = false }: { profile: DemoProfile; large?: boolean }) {
  const [failed, setFailed] = useState(false);
  return (
    <View style={[styles.portrait, large && styles.portraitLarge]}>
      {!failed ? (
        <Image
          source={caregiverPhotos[profile.id]}
          style={StyleSheet.absoluteFill}
          resizeMode="cover"
          accessibilityLabel={`Fictional AI-generated sample portrait for ${profile.name}`}
          onError={() => setFailed(true)}
        />
      ) : (
        <View style={styles.portraitFallback}>
          <Text style={styles.portraitInitial}>{profile.name.slice(0, 1)}</Text>
          <Text style={styles.portraitFallbackCaption}>Sample photo</Text>
        </View>
      )}
      <View style={styles.photoBadge}><Text style={styles.photoBadgeText}>FICTIONAL SAMPLE</Text></View>
    </View>
  );
}

function SectionTitle({ label, title }: { label: string; title: string }) {
  return (
    <View style={styles.sectionTitle}>
      <Text style={styles.eyebrow}>{label.toUpperCase()}</Text>
      <Text style={styles.sectionHeading}>{title}</Text>
    </View>
  );
}

export default function App() {
  const [setting, setSetting] = useState("Any care type");
  const [city, setCity] = useState("");
  const [pin, setPin] = useState("");
  const [careNeed, setCareNeed] = useState("Any support need");
  const [date, setDate] = useState("");
  const [startTime, setStartTime] = useState("");
  const [duration, setDuration] = useState("Any duration");
  const [skill, setSkill] = useState("Any skill");
  const [language, setLanguage] = useState("Any language");
  const [minimumExperience, setMinimumExperience] = useState(0);
  const [maxPrice, setMaxPrice] = useState(400);
  const [reviewStatus, setReviewStatus] = useState("Any review status");
  const [availability, setAvailability] = useState(false);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [selectedProfile, setSelectedProfile] = useState<DemoProfile | null>(null);
  const [requestPreviewReady, setRequestPreviewReady] = useState(false);

  const results = useMemo(() => demoCaregivers.filter((profile) => {
    const normalizedCity = city.trim().toLowerCase();
    const matchesCity = !normalizedCity || profile.city.toLowerCase().includes(normalizedCity) || profile.area.toLowerCase().includes(normalizedCity);
    const matchesPin = !pin.trim() || profile.pinCode.startsWith(pin.trim());
    const matchesSetting = setting === "Any care type" || profile.settings.includes(setting);
    const matchesNeed = careNeed === "Any support need" || profile.skills.includes(careNeed);
    const matchesSkill = skill === "Any skill" || profile.skills.includes(skill);
    const matchesLanguage = language === "Any language" || profile.languages.includes(language);
    const matchesExperience = profile.years >= minimumExperience;
    const matchesPrice = profile.priceInr <= maxPrice;
    const matchesReviews = reviewStatus === "Any review status" || (reviewStatus === "No eligible reviews yet" && profile.eligibleReviewCount === 0) || (reviewStatus === "Has eligible reviews" && profile.eligibleReviewCount > 0);
    const matchesAvailability = !availability || profile.availability.startsWith("Illustrative");
    return matchesCity && matchesPin && matchesSetting && matchesNeed && matchesSkill && matchesLanguage && matchesExperience && matchesPrice && matchesReviews && matchesAvailability;
  }), [availability, careNeed, city, language, maxPrice, minimumExperience, pin, reviewStatus, setting, skill]);

  const resetFilters = () => {
    setSetting("Any care type");
    setCity("");
    setPin("");
    setCareNeed("Any support need");
    setDate("");
    setStartTime("");
    setDuration("Any duration");
    setSkill("Any skill");
    setLanguage("Any language");
    setMinimumExperience(0);
    setMaxPrice(400);
    setReviewStatus("Any review status");
    setAvailability(false);
  };

  const openMatch = (profile: DemoProfile) => {
    Keyboard.dismiss();
    setSelectedProfile(profile);
    setRequestPreviewReady(false);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar style="dark" />
      <ScrollView contentContainerStyle={styles.page} keyboardShouldPersistTaps="handled">
        <View style={styles.header}>
          <Image source={kaadjiLogo} style={styles.logo} resizeMode="contain" accessibilityLabel="Kaadji logo" />
          <View style={styles.headerCopy}>
            <Text style={styles.brand}>Care, closer to home.</Text>
            <Text style={styles.headerTagline}>PREVENT · CARE · HEAL</Text>
          </View>
          <View style={styles.prototypePill}><Text style={styles.prototypePillText}>DEMO</Text></View>
        </View>

        <View style={styles.hero}>
          <Text style={styles.eyebrow}>KAADJI CARE SEARCH</Text>
          <Text style={styles.heroTitle}>Thoughtful support, starting with what matters.</Text>
          <Text style={styles.bodyText}>Explore five fictional Maharashtra caregiver profiles. Search and filters work locally—there is no live availability or booking.</Text>
        </View>

        <View style={styles.notice}>
          <Text style={styles.noticeTitle}>Prototype data only</Text>
          <Text style={styles.noticeText}>Fictional people and AI-generated portraits. Not real, verified, rated or available caregivers.</Text>
        </View>

        <View style={styles.card}>
          <SectionTitle label="Step 1" title="Tell us about the support" />
          <Text style={styles.fieldLabel}>Care setting</Text>
          <View style={styles.chipRow}>
            {["Any care type", "Home care", "Hospital care"].map((value) => <Chip key={value} label={value} selected={setting === value} onPress={() => setSetting(value)} />)}
          </View>

          <Text style={styles.fieldLabel}>City or neighbourhood</Text>
          <TextInput value={city} onChangeText={setCity} placeholder="Try Pune, Dadar or Nashik" placeholderTextColor="#89968c" autoCapitalize="words" style={styles.input} accessibilityLabel="Search city or neighbourhood" />
          <Text style={styles.fieldLabel}>PIN code (search only)</Text>
          <TextInput value={pin} onChangeText={(value) => setPin(value.replace(/\D/g, "").slice(0, 6))} placeholder="Try 411038" placeholderTextColor="#89968c" keyboardType="number-pad" maxLength={6} style={styles.input} accessibilityLabel="Search PIN code" />

          <Text style={styles.fieldLabel}>Non-clinical support need</Text>
          <View style={styles.chipRow}>
            {["Any support need", "Companionship", "Daily living", "Mobility support", "Supervision"].map((value) => <Chip key={value} label={value} selected={careNeed === value} onPress={() => setCareNeed(value)} />)}
          </View>

          <Pressable accessibilityRole="button" accessibilityState={{ expanded: filtersOpen }} onPress={() => setFiltersOpen((open) => !open)} style={styles.filterToggle}>
            <Text style={styles.filterToggleText}>{filtersOpen ? "Hide more filters" : "More filters"}</Text>
            <Text style={styles.filterToggleIcon}>{filtersOpen ? "−" : "+"}</Text>
          </Pressable>

          {filtersOpen && <View style={styles.moreFilters}>
            <Text style={styles.fieldLabel}>Language</Text>
            <View style={styles.chipRow}>{["Any language", "Marathi", "Hindi", "English"].map((value) => <Chip key={value} label={value} selected={language === value} onPress={() => setLanguage(value)} />)}</View>
            <Text style={styles.fieldLabel}>Minimum experience</Text>
            <View style={styles.chipRow}>{[0, 3, 5, 8].map((value) => <Chip key={value} label={value === 0 ? "Any" : `${value}+ years`} selected={minimumExperience === value} onPress={() => setMinimumExperience(value)} />)}</View>
            <Text style={styles.fieldLabel}>Skill filter</Text>
            <View style={styles.chipRow}>{["Any skill", "Companionship", "Daily living", "Mobility support", "Supervision"].map((value) => <Chip key={value} label={value} selected={skill === value} onPress={() => setSkill(value)} />)}</View>
            <Text style={styles.fieldLabel}>Rating / review status</Text>
            <View style={styles.chipRow}>{["Any review status", "No eligible reviews yet", "Has eligible reviews"].map((value) => <Chip key={value} label={value === "Any review status" ? "Any" : value} selected={reviewStatus === value} onPress={() => setReviewStatus(value)} />)}</View>
            <Text style={styles.fieldLabel}>Maximum proposed price</Text>
            <View style={styles.chipRow}><Chip label="₹400 or less" selected={maxPrice === 400} onPress={() => setMaxPrice(400)} /><Chip label="Under ₹400" selected={maxPrice === 0} onPress={() => setMaxPrice(0)} /></View>
            <Text style={styles.fieldLabel}>Availability</Text>
            <View style={styles.chipRow}><Chip label="Any availability" selected={!availability} onPress={() => setAvailability(false)} /><Chip label="Illustrative dates only" selected={availability} onPress={() => setAvailability(true)} /></View>
            <Text style={styles.sampleHint}>₹400 is only a proposed rate for a defined 24-hour arrangement; final duties and working conditions are not defined.</Text>
          </View>}

          <Text style={styles.fieldLabel}>Preferred date (optional)</Text>
          <TextInput value={date} onChangeText={setDate} placeholder="YYYY-MM-DD" placeholderTextColor="#89968c" style={styles.input} accessibilityLabel="Preferred date for the sample request" />
          <Text style={styles.fieldLabel}>Preferred start time (optional)</Text>
          <TextInput value={startTime} onChangeText={setStartTime} placeholder="For example, 09:00" placeholderTextColor="#89968c" style={styles.input} accessibilityLabel="Preferred start time for the sample request" />
          <Text style={styles.fieldLabel}>Expected duration</Text>
          <View style={styles.chipRow}>{["Any duration", "Short visit", "Daytime", "Proposed 24-hour · undefined"].map((value) => <Chip key={value} label={value} selected={duration === value} onPress={() => setDuration(value)} />)}</View>

          <View style={styles.privacyHint}><Text style={styles.privacyIcon}>●</Text><Text style={styles.privacyText}>This app keeps your search on this device. No name, phone, exact address or sensitive health notes are requested.</Text></View>
        </View>

        <View style={styles.resultsHeader}>
          <View><Text style={styles.eyebrow}>STEP 2 · COMPARE</Text><Text style={styles.sectionHeading}>Caregiver examples</Text></View>
          <Text style={styles.resultCount}>{results.length} / 5</Text>
        </View>
        <Text style={styles.resultsSubhead}>Fictional sample profiles · no live search</Text>

        {results.length > 0 ? results.map((profile) => (
          <View style={styles.profileCard} key={profile.id}>
            <CaregiverPortrait profile={profile} />
            <View style={styles.profileCopy}>
              <View style={styles.nameLine}><Text style={styles.profileName}>{profile.name}</Text><Text style={styles.sampleBadge}>SAMPLE</Text></View>
              <Text style={styles.profileLocation}>{profile.area}, {profile.city} · illustrative area</Text>
              <Text style={styles.profileIntro} numberOfLines={2}>{profile.intro}</Text>
              <View style={styles.tagRow}>{profile.skills.slice(0, 2).map((value) => <Text key={value} style={styles.tag}>{value}</Text>)}</View>
              <Text style={styles.profileFact}>{profile.years} years' experience · illustrative</Text>
              <Text style={styles.profileFact}>{profile.settings.join(" · ")}</Text>
              <Text style={styles.profileFact}>No eligible reviews · verification not live</Text>
              <Text style={styles.availability}>{profile.availability}</Text>
              <View style={styles.cardFooter}>
                <View><Text style={styles.price}>₹{profile.priceInr}</Text><Text style={styles.priceNote}>proposed / 24 hours*</Text></View>
                <Pressable accessibilityRole="button" onPress={() => openMatch(profile)} style={styles.detailsButton}><Text style={styles.detailsButtonText}>View match details</Text></Pressable>
              </View>
            </View>
          </View>
        )) : (
          <View style={styles.emptyState}>
            <Text style={styles.emptyTitle}>No sample profiles match</Text>
            <Text style={styles.bodyText}>A live service would route this request to operator assistance. This prototype has no live operator.</Text>
            <Pressable accessibilityRole="button" onPress={resetFilters} style={styles.outlineButton}><Text style={styles.outlineButtonText}>Clear filters</Text></Pressable>
          </View>
        )}

        <View style={styles.priceNotice}>
          <Text style={styles.noticeTitle}>Price and care boundaries</Text>
          <Text style={styles.noticeText}>₹400 is a provisional idea for a defined 24-hour arrangement—not a final quote. Duties, attendance, rest, handovers, meals, transport, extensions and staffing must be defined before launch. Care shown here is non-clinical; this is not a nursing service.</Text>
          <Text style={styles.noticeText}>The proposed ₹200/month family and caregiver subscriptions are separate; no payment is taken in this app.</Text>
        </View>

        <Text style={styles.footerText}>Kaadji prototype · No live 24/7 support or replacement service. In an emergency in India, call 112.</Text>
      </ScrollView>

      <Modal visible={Boolean(selectedProfile)} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setSelectedProfile(null)}>
        <SafeAreaView style={styles.modalSafe}>
          <ScrollView contentContainerStyle={styles.modalContent}>
            <View style={styles.modalTopRow}>
              <Text style={styles.eyebrow}>MATCH DETAILS · SAMPLE ONLY</Text>
              <Pressable accessibilityRole="button" accessibilityLabel="Close match details" onPress={() => setSelectedProfile(null)} style={styles.closeButton}><Text style={styles.closeButtonText}>Close</Text></Pressable>
            </View>
            {requestPreviewReady ? (
              <View style={styles.confirmation}>
                <Text style={styles.confirmationMark}>✓</Text>
                <Text style={styles.sectionHeading}>Sample request preview ready</Text>
                <Text style={styles.bodyText}>Nothing was sent and no booking was created. Caregiver acceptance and a confirmed booking would be required before private details could be considered.</Text>
                <Text style={styles.privacyText}>{demoPrivacyNotice}</Text>
              </View>
            ) : selectedProfile && <>
              <View style={styles.modalProfileHead}>
                <CaregiverPortrait profile={selectedProfile} large />
                <View style={styles.modalProfileCopy}>
                  <Text style={styles.sampleBadge}>FICTIONAL CAREGIVER</Text>
                  <Text style={styles.modalName}>{selectedProfile.name}</Text>
                  <Text style={styles.profileLocation}>{selectedProfile.area}, {selectedProfile.city} · sample area</Text>
                </View>
              </View>

              <View style={styles.summaryCard}>
                <Text style={styles.eyebrow}>PATIENT CARE SUMMARY · NON-IDENTIFYING</Text>
                <Text style={styles.sectionHeading}>Matched request</Text>
                <DetailRow label="Care setting" value={setting === "Any care type" ? "Not specified · any setting" : setting} />
                <DetailRow label="Non-clinical support need" value={careNeed === "Any support need" ? "Not specified" : careNeed} />
                <DetailRow label="General area" value={city.trim() || "Not specified"} />
                <DetailRow label="Preferred schedule" value={[date || "Date not set", startTime || "time not set", duration === "Any duration" ? "duration not specified" : duration].join(" · ")} />
                <Text style={styles.privacyText}>{demoPrivacyNotice}</Text>
              </View>

              <View style={styles.detailsCard}>
                <Text style={styles.eyebrow}>CAREGIVER DETAILS · ILLUSTRATIVE</Text>
                <DetailRow label="Verification" value="Not verified — example only" />
                <DetailRow label="Experience" value={`${selectedProfile.years} years · sample only`} />
                <DetailRow label="Skills and languages" value={`${selectedProfile.skills.join(", ")} · ${selectedProfile.languages.join(", ")}`} />
                <DetailRow label="Training / qualifications" value={selectedProfile.training} />
                <DetailRow label="Care settings" value={selectedProfile.settings.join(" · ")} />
                <DetailRow label="Availability" value="Not live" />
                <DetailRow label="Eligible reviews" value="None in this prototype" />
                <DetailRow label="Proposed service charge" value={`₹${selectedProfile.priceInr} / defined 24 hours · provisional`} />
                <DetailRow label="Monthly subscription" value="₹200 family and ₹200 caregiver · separate proposal" />
              </View>

              <Pressable accessibilityRole="button" onPress={() => setRequestPreviewReady(true)} style={styles.primaryButton}>
                <Text style={styles.primaryButtonText}>Show demo request acknowledgement</Text>
              </Pressable>
              <Text style={styles.footerText}>Local demonstration only. No patient or caregiver information is sent or persisted.</Text>
            </>}
          </ScrollView>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.detailRow}>
      <Text style={styles.detailLabel}>{label}</Text>
      <Text style={styles.detailValue}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: "#fbfaf6" },
  page: { paddingHorizontal: 18, paddingBottom: 34 },
  header: { minHeight: 82, flexDirection: "row", alignItems: "center", paddingTop: 5, borderBottomWidth: 1, borderBottomColor: "#e4e7df", marginBottom: 20 },
  logo: { width: 66, height: 66 },
  headerCopy: { flex: 1, marginLeft: 5 },
  brand: { color: "#16453e", fontSize: 17, fontWeight: "800" },
  headerTagline: { marginTop: 4, color: "#748c78", fontSize: 9, fontWeight: "800", letterSpacing: 1.4 },
  prototypePill: { paddingVertical: 7, paddingHorizontal: 11, borderRadius: 999, borderWidth: 1, borderColor: "#eeddd2", backgroundColor: "#f7ece6" },
  prototypePillText: { color: "#93644f", fontSize: 10, fontWeight: "800", letterSpacing: 0.8 },
  hero: { paddingTop: 3, paddingBottom: 15 },
  eyebrow: { color: "#748c78", fontSize: 10, fontWeight: "800", letterSpacing: 1.2 },
  heroTitle: { marginTop: 8, marginBottom: 9, color: "#183532", fontSize: 29, lineHeight: 35, fontWeight: "700" },
  bodyText: { color: "#60726b", fontSize: 14, lineHeight: 21 },
  notice: { marginBottom: 15, padding: 13, borderRadius: 12, backgroundColor: "#f7f1e9", borderWidth: 1, borderColor: "#ede2d5" },
  noticeTitle: { color: "#765c47", fontSize: 12, fontWeight: "800", marginBottom: 4 },
  noticeText: { color: "#786c5e", fontSize: 12, lineHeight: 18, marginTop: 4 },
  card: { padding: 15, marginBottom: 22, borderWidth: 1, borderColor: "#e4e7df", borderRadius: 18, backgroundColor: "#fffefa" },
  sectionTitle: { marginBottom: 12 },
  sectionHeading: { marginTop: 4, color: "#183532", fontSize: 20, lineHeight: 26, fontWeight: "700" },
  fieldLabel: { marginTop: 12, marginBottom: 7, color: "#53675e", fontSize: 12, fontWeight: "700" },
  input: { minHeight: 48, paddingHorizontal: 13, borderWidth: 1, borderColor: "#dfe5dd", borderRadius: 11, color: "#183532", backgroundColor: "#fffefa", fontSize: 14 },
  chipRow: { flexDirection: "row", flexWrap: "wrap", gap: 7 },
  chip: { minHeight: 38, justifyContent: "center", paddingHorizontal: 12, borderWidth: 1, borderColor: "#dfe5dd", borderRadius: 999, backgroundColor: "#fffefa" },
  chipSelected: { borderColor: "#779987", backgroundColor: "#eaf2ed" },
  chipText: { color: "#64776c", fontSize: 11, fontWeight: "600" },
  chipTextSelected: { color: "#16453e", fontWeight: "800" },
  filterToggle: { minHeight: 46, marginTop: 14, flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderTopWidth: 1, borderTopColor: "#edf0e9" },
  filterToggleText: { color: "#20584f", fontSize: 13, fontWeight: "800" },
  filterToggleIcon: { color: "#20584f", fontSize: 23, fontWeight: "400" },
  moreFilters: { paddingBottom: 7 },
  sampleHint: { color: "#8a7a65", fontSize: 11, lineHeight: 16, marginTop: 10 },
  privacyHint: { flexDirection: "row", gap: 9, alignItems: "flex-start", marginTop: 16, padding: 11, borderRadius: 10, backgroundColor: "#eff4ee" },
  privacyIcon: { color: "#77907d", fontSize: 11, marginTop: 2 },
  privacyText: { flex: 1, color: "#687b70", fontSize: 11, lineHeight: 16, marginTop: 9 },
  resultsHeader: { flexDirection: "row", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 4 },
  resultsSubhead: { color: "#809087", fontSize: 12, marginBottom: 11 },
  resultCount: { color: "#20584f", fontSize: 14, fontWeight: "800" },
  profileCard: { flexDirection: "row", gap: 11, marginBottom: 11, padding: 10, borderRadius: 15, borderWidth: 1, borderColor: "#e4e7df", backgroundColor: "#fffefa" },
  portrait: { width: 90, height: 118, flexShrink: 0, overflow: "hidden", borderRadius: 11, backgroundColor: "#e6ece3" },
  portraitLarge: { width: 94, height: 115, borderRadius: 14 },
  portraitFallback: { flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: "#dce8dd" },
  portraitInitial: { color: "#20584f", fontSize: 34, fontWeight: "700" },
  portraitFallbackCaption: { color: "#687b70", fontSize: 9, marginTop: 3 },
  photoBadge: { position: "absolute", left: 4, right: 4, bottom: 5, alignItems: "center", paddingVertical: 4, borderRadius: 999, backgroundColor: "rgba(24,53,50,0.75)" },
  photoBadgeText: { color: "#fffefa", fontSize: 7, fontWeight: "800", letterSpacing: 0.35 },
  profileCopy: { flex: 1, minWidth: 0 },
  nameLine: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 5 },
  profileName: { flexShrink: 1, color: "#183532", fontSize: 15, fontWeight: "800" },
  sampleBadge: { alignSelf: "flex-start", color: "#87664f", backgroundColor: "#f4eee7", borderRadius: 999, paddingHorizontal: 7, paddingVertical: 4, fontSize: 8, fontWeight: "800", letterSpacing: 0.4 },
  profileLocation: { marginTop: 4, color: "#74847b", fontSize: 10, lineHeight: 15 },
  profileIntro: { marginTop: 6, color: "#62756b", fontSize: 11, lineHeight: 16 },
  tagRow: { flexDirection: "row", flexWrap: "wrap", gap: 5, marginTop: 7 },
  tag: { color: "#617568", backgroundColor: "#eff3ec", borderRadius: 999, paddingHorizontal: 7, paddingVertical: 4, fontSize: 9 },
  profileFact: { marginTop: 5, color: "#78877e", fontSize: 10, lineHeight: 14 },
  availability: { marginTop: 5, color: "#96724e", fontSize: 9, lineHeight: 13 },
  cardFooter: { flexDirection: "row", alignItems: "flex-end", justifyContent: "space-between", gap: 6, marginTop: 9, paddingTop: 8, borderTopWidth: 1, borderTopColor: "#edf0e9" },
  price: { color: "#16453e", fontSize: 16, fontWeight: "800" },
  priceNote: { color: "#86928a", fontSize: 8 },
  detailsButton: { minHeight: 40, justifyContent: "center", paddingHorizontal: 10, borderRadius: 999, backgroundColor: "#20584f" },
  detailsButtonText: { color: "#fffefa", fontSize: 10, fontWeight: "800" },
  emptyState: { padding: 18, borderRadius: 14, backgroundColor: "#fffefa", borderWidth: 1, borderColor: "#e4e7df" },
  emptyTitle: { marginBottom: 7, color: "#183532", fontSize: 17, fontWeight: "800" },
  outlineButton: { minHeight: 44, alignSelf: "flex-start", justifyContent: "center", marginTop: 12, paddingHorizontal: 15, borderWidth: 1, borderColor: "#b6c8bd", borderRadius: 999 },
  outlineButtonText: { color: "#20584f", fontSize: 12, fontWeight: "800" },
  priceNotice: { marginTop: 11, padding: 14, borderRadius: 13, backgroundColor: "#f2f4ed" },
  footerText: { marginTop: 16, marginBottom: 7, color: "#87938b", fontSize: 10, lineHeight: 15, textAlign: "center" },
  modalSafe: { flex: 1, backgroundColor: "#fbfaf6" },
  modalContent: { padding: 17, paddingBottom: 35 },
  modalTopRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 15 },
  closeButton: { minHeight: 40, minWidth: 54, justifyContent: "center", alignItems: "center", paddingHorizontal: 10, borderRadius: 999, backgroundColor: "#eaf2ed" },
  closeButtonText: { color: "#20584f", fontSize: 12, fontWeight: "800" },
  modalProfileHead: { flexDirection: "row", alignItems: "center", gap: 13, marginBottom: 15 },
  modalProfileCopy: { flex: 1 },
  modalName: { marginTop: 7, color: "#183532", fontSize: 22, fontWeight: "800" },
  summaryCard: { padding: 14, marginBottom: 12, borderRadius: 14, borderWidth: 1, borderColor: "#dce8de", backgroundColor: "#f3f6ef" },
  detailsCard: { padding: 14, marginBottom: 15, borderRadius: 14, borderWidth: 1, borderColor: "#e4e7df", backgroundColor: "#fffefa" },
  detailRow: { paddingVertical: 9, borderBottomWidth: 1, borderBottomColor: "#edf0e9" },
  detailLabel: { color: "#77887d", fontSize: 10, marginBottom: 4 },
  detailValue: { color: "#304c40", fontSize: 12, lineHeight: 17, fontWeight: "700" },
  primaryButton: { minHeight: 48, justifyContent: "center", alignItems: "center", paddingHorizontal: 14, borderRadius: 999, backgroundColor: "#20584f" },
  primaryButtonText: { color: "#fffefa", fontSize: 12, fontWeight: "800" },
  confirmation: { alignItems: "flex-start", paddingVertical: 22 },
  confirmationMark: { width: 44, height: 44, textAlign: "center", textAlignVertical: "center", overflow: "hidden", marginBottom: 14, borderRadius: 22, backgroundColor: "#e5f0e7", color: "#39724f", fontSize: 25, fontWeight: "800" },
});
