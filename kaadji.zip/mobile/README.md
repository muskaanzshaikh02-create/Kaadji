# Kaadji Android prototype

A separate Expo/React Native prototype that mirrors the web demo's fictional caregiver search and match-details flow. It is not a production service, APK/AAB release or Google Play listing.

## Run

1. Install Node.js 22+ and npm 10.9.2 (or use the Expo-compatible toolchain available on your device).
2. From this directory, run `npm install` once.
3. Run `npm start` and open the project in Expo Go, or use an Android emulator with the Expo development tools.
4. The user-supplied logo and all five generated sample portraits are bundled locally, so the app does not need a web origin or network connection to display them.

## Prototype behavior

- Five fictional caregiver profiles are searched and filtered locally; the records are shared with the web prototype from `../shared/demo-data.ts`.
- The match view displays caregiver sample attributes and a non-identifying patient care-request summary.
- Patient name, contact details, exact address and sensitive health notes are not present in the dataset. In a future live product, reveal such information only after a confirmed booking and explicit consent.
- The portraits are AI-generated fictional examples bundled in `assets/images/`; the profiles, dates, service areas, experience, prices, credentials and availability are not real or verified.
- No OTP, account, booking, payment, upload, notification, live-availability lookup or patient-data storage is implemented. All actions remain local to the prototype.

## Checks and Android bundle

- `npm run check` runs TypeScript validation.
- `npm run export:android` exports the JavaScript/assets bundle for Android; it does **not** produce an installable APK or Play Store release. A release build requires a separately approved Android build/signing workflow.
