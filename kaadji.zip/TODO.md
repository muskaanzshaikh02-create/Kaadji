# Kaadji Prototype — TODO

**Approved scope:** Responsive web prototype plus a companion native Android prototype using local fictional sample data. Full production development and public release require separate approval after prototype review.

## 1. Landing experience and navigation

- [x] Implement a mobile-first responsive landing page with the exact headline **“Kaadji — Care That Comes Closer to Home.”** and supporting text **“Find trusted care for your loved ones, at home or in the hospital.”**
- [x] Prominently provide the two actions **“Find a Caregiver”** and **“Join as a Caregiver.”**
- [x] Provide navigation for Home, Find Care, Become a Caregiver, How It Works, Help and Support, and Login, with working prototype navigation to the corresponding screen or state.
- [x] Make the layout readable and usable for senior citizens and people with limited technology confidence: readable text, clear instructions, large touch targets, short steps, visible focus and accessible labels.
- [x] Provide English and Marathi prototype language choices. Hindi may be noted as a future enhancement, not represented as complete if it is not implemented.
- [x] Use the user-supplied `KaadjiWellnessLogo.png` in the web and Android prototypes, preserving its original proportions and colours; do not invent, redraw or substitute a logo.

## 2. Patient/family care discovery and booking demonstration

- [x] Present Home Care and Hospital Care as distinct service choices and distinguish non-clinical caregiving from regulated clinical nursing. Do not imply that medical procedures are offered without appropriately qualified and authorised professionals where legally permitted.
- [x] Demonstrate the request sequence: choose care type; enter city/PIN-code location; describe care requirements; choose preferred date, time and duration; browse suitable caregiver examples; review a complete illustrative price breakdown; and submit a demo booking request.
- [x] Include five distinct fictional caregiver examples with clearly labelled realistic generated portraits and usable sample attributes, so the local search can return and filter examples by city, PIN code, price, experience, skills, review status, availability, language and service type. The Nashik search query was verified to narrow the list to one matching fictional profile.
- [x] Provide a detail view for a selected fictional caregiver with photo, sample display name, clearly labelled non-live verification state, experience, skills/training, languages, preferred work locations, home/hospital eligibility, sample availability, eligible review count, provisional price and introduction. Do not fabricate genuine ratings, reviews, credentials or live availability.
- [x] When a sample caregiver matches, show that caregiver's profile and a non-identifying patient care-request summary (care setting, requested non-clinical needs, general area and preferred schedule/duration). Keep patient name, phone, exact address and sensitive health notes hidden until a real booking is confirmed and explicit consent is recorded. Since the prototype has no real booking or patient data, do not display private patient details.
- [x] Clearly mark every demonstration caregiver and all associated information **illustrative/sample only; not a real caregiver, verification, review, price quote or live availability**. Do not create fake testimonials or ratings; show no rating or an explicit “No eligible prototype reviews” state.
- [x] If a prototype filter produces no matches, offer a request for operator assistance rather than implying that a caregiver is available.
- [x] Show the proposed **₹400 price for a defined 24-hour arrangement** only as provisional. Explain that attendance, rest/sleep, duties, handovers, transport, meals, extensions, staffing and applicable work conditions must be defined before launch. Do not imply one caregiver works uninterrupted for 24 hours.
- [x] Show the **single standard ₹200 monthly subscription** concept separately for patient/family and caregiver accounts; do not add basic/premium tiers or combine the subscription with the service charge. Clearly mark prototype-only pricing terms and do not take payment or silently activate anything.

## 3. Caregiver application demonstration

- [x] Provide a staged caregiver registration/application concept with full legal-name/contact fields, profile-photo placeholder, address/service locations, languages, experience, skills, training/qualifications where applicable, availability, emergency contact and verification-document placeholders.
- [x] Distinguish identity verification from professional qualification verification. Do not call a person a nurse or clinically qualified without appropriate credentials.
- [x] Demonstrate these application statuses: Application Submitted, Verification Pending, Additional Information Required, Approved, Rejected and Temporarily Suspended. All status examples must be visibly illustrative and not real decisions.

## 4. Help, grievances, replacements and safety notices

- [x] Keep **“24/7 Help & Replacement”** visible throughout the relevant prototype surfaces. State that the prototype has no live support, and that actual 24/7 availability requires an operational staffing/on-call arrangement; do not promise immediate replacement.
- [x] Demonstrate ticket categories for caregiver non-arrival, replacement, poor service/unprofessional behaviour, payment/refund dispute, harassment/inappropriate conduct, safety concern, booking problem, verification concern and other complaint.
- [x] Show a ticket acknowledgement with a unique demo reference, timestamp, priority, assigned-operator placeholder, status, communication-history concept and resolution-record concept. Mark all information sample-only.
- [x] Provide appropriate emergency information including India's 112 number where applicable, and state that Kaadji support is not a substitute for emergency medical services.

## 5. Operator dashboard concept

- [x] Provide a separate operator/admin dashboard concept with sample-only tiles for patient and caregiver registrations, pending verification, approved/available caregivers, new/confirmed/active/completed/cancelled bookings, subscription payments, refunds/payment issues, open grievances, replacements, response/resolution times, and city/PIN demand.
- [x] Include navigational sections for users, caregivers, verification, bookings, subscriptions, payments, reviews, grievances, replacements, notifications and reports.
- [x] Mark every count and record as prototype sample data; do not expose real personal or care data or imply that access-control enforcement is operational.

## 6. Explicitly out of scope for this approval

- [x] No backend, managed database, real authentication/OTP, real uploads, personal-data collection, payment gateway, financial processing, live caregiver search/availability, real booking or notification delivery.
- [x] No APK/AAB release build, Google Play publication, production security claim, public launch, live support service, staffing commitment, caregiver verification, legal/compliance attestation or final rate/service-policy decision.
- [x] Deliver a separate Expo/React Native Android prototype under `mobile/` with portrait-oriented accessible screens, the supplied logo, local five-profile search/filter/detail flow, and the same privacy-minimized match summary as the web prototype. The Android source passed TypeScript validation and `expo export --platform android`; this is not a production app or store-release APK/AAB.
- [x] After the prototype is presented, pause and obtain separate approval before starting full development.
